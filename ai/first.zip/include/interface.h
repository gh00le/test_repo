#ifndef INTERFACE_H
#define INTERFACE_H

#include <common.h>

void print_state(const State& state);
State parse_state(const std::string& input);
void save_solution_steps(
    const std::string& filename,
    const std::string& algorithm,
    const std::string& digits,
    long long target,
    const std::vector<State>& solution,
    std::size_t expanded,
    double time_ms,
    int depth_limit,
    bool optimal,
    bool append
);

#endif
