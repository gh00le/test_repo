#ifndef GAME8_H
#define GAME8_H

#include <common.h>

void set_target(long long target);
long long get_target();

State make_initial_state(const std::string& input);
bool is_goal(const State& state);
std::list<Move> get_possible_moves(const State& state);
State make_move(const State& state, const Move& move);

std::string tree_to_string(const std::shared_ptr<ExprNode>& node);
std::string state_key(const State& state);
std::string state_expression(const State& state);
std::size_t state_size(const State& state);

double part_distance(const std::shared_ptr<ExprNode>& node, long long target);

#endif
