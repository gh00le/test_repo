#ifndef AI_H
#define AI_H

#include <common.h>

struct StateHash {
    std::size_t operator()(const State& state) const;
};

std::vector<State> reconstruct_path(
    const std::unordered_map<State, State, StateHash>& parent,
    State current
);

std::vector<State> BFS_solve(State init_state);

bool dls(
    const State& state,
    int depth,
    int limit,
    std::vector<State>& solution,
    std::unordered_set<State, StateHash>& closed
);

std::vector<State> DLS_solve(State init_state, int limit);

double heuristic1(const State& state);
double heuristic2(const State& state);

std::vector<State> EST_solve(State init_state, double (*est)(const State&));

std::size_t get_last_expanded();

#endif
