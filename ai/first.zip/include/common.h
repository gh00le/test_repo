#ifndef COMMON_H
#define COMMON_H

#include <iostream>
#include <list>
#include <memory>
#include <queue>
#include <stack>
#include <unordered_set>
#include <unordered_map>
#include <algorithm>
#include <sstream>
#include <string>
#include <vector>
#include <chrono>
#include <cmath>
#include <iomanip>
#include <functional>

struct ExprNode {
    long long num;
    long long den;
    std::string digits;
    char op;
    std::shared_ptr<ExprNode> left;
    std::shared_ptr<ExprNode> right;
};

struct State {
    std::list<std::shared_ptr<ExprNode> > trees;
    bool operator==(const State& other) const;
};

struct Move {
    std::size_t index;
    char operation;
};

#endif
