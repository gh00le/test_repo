#include <interface.h>
#include <game8.h>
#include <fstream>

void print_state(const State& state) {
    std::cout << state_expression(state) << std::endl;
}

State parse_state(const std::string& input) {
    return make_initial_state(input);
}

void save_solution_steps(
    const std::string& filename,
    const std::string& algorithm,
    const std::string& digits,
    long long target,
    const std::vector<State>& solution,
    std::size_t expanded,
    double time_ms,
    int depth_limit,
    bool optimal,
    bool append
) {
    std::ios_base::openmode mode = std::ios::out;
    if (append) mode |= std::ios::app;

    std::ofstream file(filename.c_str(), mode);
    if (!file.is_open()) return;

    file << "Algorithm: " << algorithm << std::endl;
    file << "Initial state: " << digits << std::endl;
    file << "Target: " << target << std::endl;
    file << "Expanded vertices: " << expanded << std::endl;
    file << "Execution time: " << std::fixed << std::setprecision(4) << time_ms << " ms" << std::endl;

    if (solution.empty()) {
        file << "Solution length: -" << std::endl;
    }
    else {
        file << "Solution length: " << static_cast<int>(solution.size()) - 1 << std::endl;
    }

    if (depth_limit >= 0) {
        file << "Depth limit: " << depth_limit << std::endl;
    }

    file << "Solution found: " << (solution.empty() ? "no" : "yes") << std::endl;
    file << "Optimal: " << (optimal ? "yes" : "no") << std::endl;

    if (solution.empty() || expanded == 0) {
        file << "Practicality: -" << std::endl;
    }
    else {
        double practicality = static_cast<double>(solution.size() - 1) / static_cast<double>(expanded);
        file << "Practicality: " << std::fixed << std::setprecision(6) << practicality << std::endl;
    }
    file << std::endl;

    if (solution.empty()) {
        file << "Solution steps: not available" << std::endl << std::endl;
        return;
    }

    file << "Solution steps:" << std::endl;

    for (std::size_t i = 0; i < solution.size(); ++i) {
        file << "Step " << i << ": " << state_expression(solution[i]) << std::endl;
    }

    file << "Result: " << state_expression(solution.back()) << std::endl;
    file << std::endl;
}
