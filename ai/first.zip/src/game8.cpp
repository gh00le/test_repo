#include <game8.h>

static long long CURRENT_TARGET = 0;

static long long gcd_abs(long long a, long long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;

    while (b != 0) {
        long long r = a % b;
        a = b;
        b = r;
    }

    return a == 0 ? 1 : a;
}

static void normalize(long long& num, long long& den) {
    if (den < 0) {
        num = -num;
        den = -den;
    }

    long long g = gcd_abs(num, den);
    num /= g;
    den /= g;
}

static std::shared_ptr<ExprNode> make_number_node(const std::string& digits) {
    std::shared_ptr<ExprNode> node(new ExprNode());
    node->num = std::stoll(digits);
    node->den = 1;
    node->digits = digits;
    node->op = 0;
    node->left.reset();
    node->right.reset();
    return node;
}

static std::shared_ptr<ExprNode> make_operation_node(
    const std::shared_ptr<ExprNode>& left,
    const std::shared_ptr<ExprNode>& right,
    char op
) {
    long long num = 0;
    long long den = 1;

    if (op == '+') {
        num = left->num * right->den + right->num * left->den;
        den = left->den * right->den;
    }
    else if (op == '-') {
        num = left->num * right->den - right->num * left->den;
        den = left->den * right->den;
    }
    else if (op == '*') {
        num = left->num * right->num;
        den = left->den * right->den;
    }
    else if (op == '/') {
        num = left->num * right->den;
        den = left->den * right->num;
    }

    normalize(num, den);

    std::shared_ptr<ExprNode> node(new ExprNode());
    node->num = num;
    node->den = den;
    node->digits.clear();
    node->op = op;
    node->left = left;
    node->right = right;
    return node;
}

void set_target(long long target) {
    CURRENT_TARGET = target;
}

long long get_target() {
    return CURRENT_TARGET;
}

State make_initial_state(const std::string& input) {
    State state;
    std::stringstream ss(input);
    std::string token;

    while (ss >> token) {
        state.trees.push_back(make_number_node(token));
    }

    return state;
}

bool is_goal(const State& state) {
    if (state.trees.size() != 1) return false;

    const std::shared_ptr<ExprNode>& root = state.trees.front();
    return root->num == CURRENT_TARGET * root->den;
}

std::list<Move> get_possible_moves(const State& state) {
    std::list<Move> moves;

    if (state.trees.size() < 2) return moves;

    std::list<std::shared_ptr<ExprNode> >::const_iterator left = state.trees.begin();
    std::list<std::shared_ptr<ExprNode> >::const_iterator right = left;
    ++right;

    std::size_t index = 0;

    while (right != state.trees.end()) {
        Move move;
        move.index = index;

        move.operation = '+';
        moves.push_back(move);

        move.operation = '-';
        moves.push_back(move);

        move.operation = '*';
        moves.push_back(move);

        if ((*right)->num != 0) {
            move.operation = '/';
            moves.push_back(move);
        }

        if ((*left)->op == 0 && (*right)->op == 0) {
            move.operation = 'C';
            moves.push_back(move);
        }

        ++left;
        ++right;
        ++index;
    }

    return moves;
}

State make_move(const State& state, const Move& move) {
    State next_state = state;

    std::list<std::shared_ptr<ExprNode> >::iterator left = next_state.trees.begin();
    std::advance(left, move.index);

    std::list<std::shared_ptr<ExprNode> >::iterator right = left;
    ++right;

    std::shared_ptr<ExprNode> new_node;

    if (move.operation == 'C') {
        new_node = make_number_node((*left)->digits + (*right)->digits);
    }
    else {
        new_node = make_operation_node(*left, *right, move.operation);
    }

    *left = new_node;
    next_state.trees.erase(right);

    return next_state;
}

std::string tree_to_string(const std::shared_ptr<ExprNode>& node) {
    if (!node) return "";

    if (node->op == 0) return node->digits;

    return "(" + tree_to_string(node->left) + std::string(1, node->op) + tree_to_string(node->right) + ")";
}

std::string state_key(const State& state) {
    std::ostringstream out;

    for (std::list<std::shared_ptr<ExprNode> >::const_iterator it = state.trees.begin();
         it != state.trees.end(); ++it) {
        const std::shared_ptr<ExprNode>& node = *it;

        if (node->op == 0) {
            out << "P:" << node->digits;
        }
        else {
            out << "E:" << node->num << "/" << node->den;
        }

        out << "|";
    }

    return out.str();
}

std::string state_expression(const State& state) {
    if (state.trees.empty()) return "";
    if (state.trees.size() == 1) return tree_to_string(state.trees.front());

    std::ostringstream out;
    bool first = true;

    for (std::list<std::shared_ptr<ExprNode> >::const_iterator it = state.trees.begin();
         it != state.trees.end(); ++it) {
        if (!first) out << " ";
        out << tree_to_string(*it);
        first = false;
    }

    return out.str();
}

std::size_t state_size(const State& state) {
    return state.trees.size();
}

double part_distance(const std::shared_ptr<ExprNode>& node, long long target) {
    long double value = static_cast<long double>(node->num) / static_cast<long double>(node->den);
    long double diff = std::fabsl(value - static_cast<long double>(target));
    return static_cast<double>(diff);
}

bool State::operator==(const State& other) const {
    return state_key(*this) == state_key(other);
}
