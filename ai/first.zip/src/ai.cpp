#include <ai.h>
#include <game8.h>

static std::size_t LAST_EXPANDED = 0;

std::size_t StateHash::operator()(const State& state) const {
    return std::hash<std::string>()(state_key(state));
}

std::vector<State> reconstruct_path(
    const std::unordered_map<State, State, StateHash>& parent,
    State current
) {
    std::vector<State> path;

    while (true) {
        path.push_back(current);

        std::unordered_map<State, State, StateHash>::const_iterator it = parent.find(current);
        if (it == parent.end() || it->second == current) break;

        current = it->second;
    }

    std::reverse(path.begin(), path.end());
    return path;
}

std::vector<State> BFS_solve(State init_state) {
    LAST_EXPANDED = 0;

    std::queue<State> open;
    std::unordered_set<State, StateHash> closed;
    std::unordered_map<State, State, StateHash> parent;

    open.push(init_state);
    closed.insert(init_state);
    parent[init_state] = init_state;

    while (!open.empty()) {
        State current = open.front();
        open.pop();
        ++LAST_EXPANDED;

        if (is_goal(current)) return reconstruct_path(parent, current);

        std::list<Move> moves = get_possible_moves(current);

        for (std::list<Move>::const_iterator it = moves.begin(); it != moves.end(); ++it) {
            State next_state = make_move(current, *it);

            if (closed.find(next_state) == closed.end()) {
                closed.insert(next_state);
                parent[next_state] = current;
                open.push(next_state);
            }
        }
    }

    return std::vector<State>();
}

bool dls(
    const State& state,
    int depth,
    int limit,
    std::vector<State>& solution,
    std::unordered_set<State, StateHash>& closed
) {
    ++LAST_EXPANDED;
    solution.push_back(state);

    if (is_goal(state)) return true;

    if (depth >= limit) {
        solution.pop_back();
        return false;
    }

    closed.insert(state);
    std::list<Move> moves = get_possible_moves(state);

    for (std::list<Move>::const_iterator it = moves.begin(); it != moves.end(); ++it) {
        State next_state = make_move(state, *it);

        if (closed.find(next_state) == closed.end()) {
            if (dls(next_state, depth + 1, limit, solution, closed)) return true;
        }
    }

    closed.erase(state);
    solution.pop_back();
    return false;
}

std::vector<State> DLS_solve(State init_state, int limit) {
    LAST_EXPANDED = 0;

    std::vector<State> solution;
    std::unordered_set<State, StateHash> closed;

    if (dls(init_state, 0, limit, solution, closed)) return solution;

    return std::vector<State>();
}

double heuristic1(const State& state) {
    if (state.trees.empty()) return 0.0;

    double best = 1e100;
    long long target = get_target();

    for (std::list<std::shared_ptr<ExprNode> >::const_iterator it = state.trees.begin();
         it != state.trees.end(); ++it) {
        double value = part_distance(*it, target);
        if (value < best) best = value;
    }

    return best;
}

double heuristic2(const State& state) {
    if (is_goal(state)) return 0.0;

    std::list<Move> moves = get_possible_moves(state);
    if (moves.empty()) return heuristic1(state);

    double best = 1e100;

    for (std::list<Move>::const_iterator it = moves.begin(); it != moves.end(); ++it) {
        State next_state = make_move(state, *it);
        double value = heuristic1(next_state);
        if (value < best) best = value;
    }

    return best;
}

std::vector<State> EST_solve(State init_state, double (*est)(const State&)) {
    LAST_EXPANDED = 0;

    typedef std::pair<double, State> StateEst;

    struct Compare {
        bool operator()(const StateEst& a, const StateEst& b) const {
            return a.first > b.first;
        }
    };

    std::priority_queue<StateEst, std::vector<StateEst>, Compare> open;
    std::unordered_set<State, StateHash> closed;
    std::unordered_map<State, State, StateHash> parent;

    open.push(StateEst(est(init_state), init_state));
    parent[init_state] = init_state;

    while (!open.empty()) {
        State current = open.top().second;
        open.pop();

        if (closed.find(current) != closed.end()) continue;

        closed.insert(current);
        ++LAST_EXPANDED;

        if (is_goal(current)) return reconstruct_path(parent, current);

        std::list<Move> moves = get_possible_moves(current);

        for (std::list<Move>::const_iterator it = moves.begin(); it != moves.end(); ++it) {
            State next_state = make_move(current, *it);

            if (closed.find(next_state) == closed.end()) {
                if (parent.find(next_state) == parent.end()) {
                    parent[next_state] = current;
                }

                open.push(StateEst(est(next_state), next_state));
            }
        }
    }

    return std::vector<State>();
}

std::size_t get_last_expanded() {
    return LAST_EXPANDED;
}
