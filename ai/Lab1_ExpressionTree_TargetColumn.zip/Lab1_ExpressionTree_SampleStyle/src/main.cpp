#include <ai.h>
#include <interface.h>
#include <game8.h>
#include <fstream>

struct TestCase {
    std::string digits;
    long long target;
};

struct TestResult {
    std::string digits;
    long long target;

    std::vector<State> bfs;
    std::size_t bfs_expanded;
    double bfs_time;

    std::vector<State> dls;
    std::size_t dls_expanded;
    double dls_time;
    int dls_limit;

    std::vector<State> h1;
    std::size_t h1_expanded;
    double h1_time;

    std::vector<State> h2;
    std::size_t h2_expanded;
    double h2_time;
};

static void print_result(
    const std::string& algorithm,
    const std::string& digits,
    long long target,
    const std::vector<State>& solution,
    std::size_t expanded,
    double time_ms,
    int dls_limit,
    bool optimal
) {
    std::cout << algorithm << std::endl;
    std::cout << "Initial state: " << digits << std::endl;
    std::cout << "Target: " << target << std::endl;
    std::cout << "Expanded vertices: " << expanded << std::endl;
    std::cout << "Execution time: " << std::fixed << std::setprecision(4) << time_ms << " ms" << std::endl;

    if (solution.empty()) {
        std::cout << "Solution length: -" << std::endl;
    }
    else {
        std::cout << "Solution length: " << static_cast<int>(solution.size()) - 1 << std::endl;
    }

    if (dls_limit >= 0) {
        std::cout << "Depth limit: " << dls_limit << std::endl;
    }

    std::cout << "Solution found: " << (solution.empty() ? "no" : "yes") << std::endl;
    std::cout << "Optimal: " << (optimal ? "yes" : "no") << std::endl;

    if (solution.empty() || expanded == 0) {
        std::cout << "Practicality: -" << std::endl;
    }
    else {
        double practicality = static_cast<double>(solution.size() - 1) / static_cast<double>(expanded);
        std::cout << "Practicality: " << std::fixed << std::setprecision(6) << practicality << std::endl;
    }

    std::cout << std::endl;
}

static bool is_optimal_solution(const std::string& digits, const std::vector<State>& solution) {
    if (solution.empty()) return false;

    State start = parse_state(digits);
    int minimum_length = static_cast<int>(state_size(start)) - 1;
    int actual_length = static_cast<int>(solution.size()) - 1;

    return actual_length == minimum_length;
}


static std::string format_time(double time_ms) {
    std::ostringstream out;
    out << std::fixed << std::setprecision(4) << time_ms;
    return out.str();
}

static std::string solution_length_text(const std::vector<State>& solution) {
    if (solution.empty()) return "-";

    std::ostringstream out;
    out << static_cast<int>(solution.size()) - 1;
    return out.str();
}

static std::string practicality_text(const std::vector<State>& solution, std::size_t expanded) {
    if (solution.empty() || expanded == 0) return "-";

    double practicality = static_cast<double>(solution.size() - 1) / static_cast<double>(expanded);
    std::ostringstream out;
    out << std::fixed << std::setprecision(6) << practicality;
    return out.str();
}

static std::string bracket_state(const std::string& digits) {
    return "[" + digits + "]";
}

static void write_results_separator(std::ostream& out) {
    out << std::string(139, '-') << std::endl;
}

static void write_results_header(std::ostream& out) {
    out << std::left
        << std::setw(40) << "Initial state"
        << " | " << std::setw(8) << "Target"
        << " | " << std::setw(10) << "Expanded"
        << " | " << std::setw(10) << "Time, ms"
        << " | " << std::setw(6) << "Length"
        << " | " << std::setw(9) << "Depth lim"
        << " | " << std::setw(6) << "Found"
        << " | " << std::setw(8) << "Optimal"
        << " | " << std::setw(15) << "P = L/N"
        << std::endl;
}

static void write_results_row(
    std::ostream& out,
    const std::string& digits,
    long long target,
    const std::vector<State>& solution,
    std::size_t expanded,
    double time_ms,
    int depth_limit,
    bool optimal
) {
    std::string depth_text = "--";
    if (depth_limit >= 0) {
        std::ostringstream value;
        value << depth_limit;
        depth_text = value.str();
    }

    std::string length_text = "--";
    if (!solution.empty()) {
        std::ostringstream value;
        value << static_cast<int>(solution.size()) - 1;
        length_text = value.str();
    }

    std::string practical = "--";
    if (!solution.empty() && expanded != 0) {
        double p = static_cast<double>(solution.size() - 1) / static_cast<double>(expanded);
        std::ostringstream value;
        value << std::fixed << std::setprecision(6) << p;
        practical = value.str();
    }

    out << std::left
        << std::setw(40) << bracket_state(digits)
        << " | " << std::setw(8) << target
        << " | " << std::setw(10) << expanded
        << " | " << std::setw(10) << format_time(time_ms)
        << " | " << std::setw(6) << length_text
        << " | " << std::setw(9) << depth_text
        << " | " << std::setw(6) << (solution.empty() ? "no" : "yes")
        << " | " << std::setw(8) << (optimal ? "yes" : "no")
        << " | " << std::setw(15) << practical
        << std::endl;
}

static void save_result_table(const std::vector<TestResult>& results) {
    std::ofstream file("results.txt");
    if (!file.is_open()) return;

    file << "Table 1. Breadth-First Search (BFS) results" << std::endl;
    file << "Effectiveness column: P = L / N." << std::endl << std::endl;
    write_results_header(file);
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_results_row(
            file, results[i].digits, results[i].target, results[i].bfs, results[i].bfs_expanded,
            results[i].bfs_time, -1, is_optimal_solution(results[i].digits, results[i].bfs)
        );
    }

    file << std::endl;
    write_results_separator(file);
    file << std::endl << "Table 2. Depth-Limited Search (DLS) results" << std::endl;
    file << "Depth limit: N - 1 for each initial state." << std::endl;
    file << "Effectiveness column: P = L / N." << std::endl << std::endl;
    write_results_header(file);
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_results_row(
            file, results[i].digits, results[i].target, results[i].dls, results[i].dls_expanded,
            results[i].dls_time, results[i].dls_limit, is_optimal_solution(results[i].digits, results[i].dls)
        );
    }

    file << std::endl;
    write_results_separator(file);
    file << std::endl << "Table 3. Heuristic search (EST), heuristic: H1" << std::endl;
    file << "Effectiveness column: P = L / N." << std::endl << std::endl;
    write_results_header(file);
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_results_row(
            file, results[i].digits, results[i].target, results[i].h1, results[i].h1_expanded,
            results[i].h1_time, -1, is_optimal_solution(results[i].digits, results[i].h1)
        );
    }

    file << std::endl;
    write_results_separator(file);
    file << std::endl << "Table 4. Heuristic search (EST), heuristic: H2" << std::endl;
    file << "Effectiveness column: P = L / N." << std::endl << std::endl;
    write_results_header(file);
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_results_row(
            file, results[i].digits, results[i].target, results[i].h2, results[i].h2_expanded,
            results[i].h2_time, -1, is_optimal_solution(results[i].digits, results[i].h2)
        );
    }

    file << std::endl;
    write_results_separator(file);
}

static void write_moves_block(
    std::ostream& out,
    const std::string& digits,
    const std::vector<State>& solution,
    int depth_limit
) {
    if (depth_limit >= 0) {
        out << "Depth limit: " << depth_limit << std::endl << std::endl;
    }

    out << "Initial state: " << bracket_state(digits) << std::endl << std::endl;

    if (solution.empty()) {
        out << "Solution was not found." << std::endl << std::endl;
        return;
    }

    for (std::size_t i = 0; i < solution.size(); ++i) {
        out << "Step " << i << ":" << std::endl;
        out << state_expression(solution[i]) << std::endl << std::endl;
    }
}

static void save_moves_file(const std::vector<TestResult>& results) {
    std::ofstream file("moves.txt");
    if (!file.is_open()) return;

    file << "Breadth-First Search (BFS)" << std::endl << std::endl;
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_moves_block(file, results[i].digits, results[i].bfs, -1);
    }

    file << "Depth-Limited Search (DLS)" << std::endl << std::endl;
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_moves_block(file, results[i].digits, results[i].dls, results[i].dls_limit);
    }

    file << "Heuristic search (EST), heuristic: H1" << std::endl << std::endl;
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_moves_block(file, results[i].digits, results[i].h1, -1);
    }

    file << "Heuristic search (EST), heuristic: H2" << std::endl << std::endl;
    for (std::size_t i = 0; i < results.size(); ++i) {
        write_moves_block(file, results[i].digits, results[i].h2, -1);
    }
}

static TestResult run_test(const std::string& digits, long long target) {
    set_target(target);
    State start = parse_state(digits);
    int limit = static_cast<int>(state_size(start)) - 1;

    TestResult result;
    result.digits = digits;
    result.target = target;
    result.dls_limit = limit;

    std::cout << "Digits: " << digits << std::endl;
    std::cout << "Target: " << target << std::endl << std::endl;

    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    result.bfs = BFS_solve(start);
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    result.bfs_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.bfs_expanded = get_last_expanded();
    print_result(
        "BFS",
        digits,
        target,
        result.bfs,
        result.bfs_expanded,
        result.bfs_time,
        -1,
        is_optimal_solution(digits, result.bfs)
    );

    begin = std::chrono::steady_clock::now();
    result.dls = DLS_solve(start, limit);
    end = std::chrono::steady_clock::now();
    result.dls_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.dls_expanded = get_last_expanded();
    print_result(
        "DLS",
        digits,
        target,
        result.dls,
        result.dls_expanded,
        result.dls_time,
        limit,
        is_optimal_solution(digits, result.dls)
    );

    begin = std::chrono::steady_clock::now();
    result.h1 = EST_solve(start, heuristic1);
    end = std::chrono::steady_clock::now();
    result.h1_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.h1_expanded = get_last_expanded();
    print_result(
        "Heuristic H1",
        digits,
        target,
        result.h1,
        result.h1_expanded,
        result.h1_time,
        -1,
        is_optimal_solution(digits, result.h1)
    );

    begin = std::chrono::steady_clock::now();
    result.h2 = EST_solve(start, heuristic2);
    end = std::chrono::steady_clock::now();
    result.h2_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.h2_expanded = get_last_expanded();
    print_result(
        "Heuristic H2",
        digits,
        target,
        result.h2,
        result.h2_expanded,
        result.h2_time,
        -1,
        is_optimal_solution(digits, result.h2)
    );

    return result;
}

static void save_all_results(const std::vector<TestResult>& results) {
    for (std::size_t i = 0; i < results.size(); ++i) {
        bool append = i != 0;

        save_solution_steps(
            "result_BFS.txt",
            "BFS",
            results[i].digits,
            results[i].target,
            results[i].bfs,
            results[i].bfs_expanded,
            results[i].bfs_time,
            -1,
            is_optimal_solution(results[i].digits, results[i].bfs),
            append
        );

        save_solution_steps(
            "result_DLS.txt",
            "DLS",
            results[i].digits,
            results[i].target,
            results[i].dls,
            results[i].dls_expanded,
            results[i].dls_time,
            results[i].dls_limit,
            is_optimal_solution(results[i].digits, results[i].dls),
            append
        );

        save_solution_steps(
            "result_H1.txt",
            "Heuristic H1",
            results[i].digits,
            results[i].target,
            results[i].h1,
            results[i].h1_expanded,
            results[i].h1_time,
            -1,
            is_optimal_solution(results[i].digits, results[i].h1),
            append
        );

        save_solution_steps(
            "result_H2.txt",
            "Heuristic H2",
            results[i].digits,
            results[i].target,
            results[i].h2,
            results[i].h2_expanded,
            results[i].h2_time,
            -1,
            is_optimal_solution(results[i].digits, results[i].h2),
            append
        );
    }

    save_result_table(results);
    save_moves_file(results);

    std::cout << "Results saved to results.txt and moves.txt" << std::endl;
    std::cout << "Detailed files result_BFS.txt, result_DLS.txt, result_H1.txt and result_H2.txt were also saved" << std::endl << std::endl;
}

static void ask_to_save(const std::vector<TestResult>& results) {
    int save = 0;
    std::cout << "Save results and solution steps to files?" << std::endl;
    std::cout << "1 - yes" << std::endl;
    std::cout << "0 - no" << std::endl;
    std::cout << "> ";
    std::cin >> save;
    std::cin.ignore(10000, '\n');
    std::cout << std::endl;

    if (save == 1) save_all_results(results);
}

int main() {
    TestCase tests[5] = {
        {"3 2 1 1 5", 36},
        {"1 2 3 4", 24},
        {"2 5 5", 50},
        {"9 1 2 3", 18},
        {"1 0 2 4 2", 512}
    };

    int mode = -1;

    while (mode != 0) {
        std::cout << "1 - prepared tests" << std::endl;
        std::cout << "2 - custom test" << std::endl;
        std::cout << "0 - exit" << std::endl;
        std::cout << "> ";
        std::cin >> mode;
        std::cin.ignore(10000, '\n');
        std::cout << std::endl;

        if (mode == 1) {
            std::vector<TestResult> results;

            for (int i = 0; i < 5; ++i) {
                std::cout << "Test " << i + 1 << std::endl;
                results.push_back(run_test(tests[i].digits, tests[i].target));
            }

            ask_to_save(results);
        }
        else if (mode == 2) {
            std::string digits;
            long long target;

            std::cout << "Enter digits separated by spaces: ";
            std::getline(std::cin, digits);

            State check = parse_state(digits);
            if (state_size(check) == 0 || state_size(check) > 6) {
                std::cout << "Number of digits must be from 1 to 6." << std::endl << std::endl;
                continue;
            }

            std::cout << "Enter target: ";
            std::cin >> target;
            std::cin.ignore(10000, '\n');
            std::cout << std::endl;

            std::vector<TestResult> results;
            results.push_back(run_test(digits, target));
            ask_to_save(results);
        }
    }

    return 0;
}
