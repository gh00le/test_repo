#include "game8.h"

// Own GCD implementation so that the file does not depend on std::gcd.
static long long abs_ll(long long x) {
    return x < 0 ? -x : x;
}

static long long gcd_abs(long long a, long long b) {
    a = abs_ll(a);
    b = abs_ll(b);

    while (b != 0) {
        long long r = a % b;
        a = b;
        b = r;
    }
    return a;
}

Fraction make_fraction(long long num, long long den) {
    if (den == 0) {
        throw std::runtime_error("division by zero");
    }

    if (den < 0) {
        num = -num;
        den = -den;
    }

    long long g = gcd_abs(num, den);
    if (g == 0) {
        return Fraction(0, 1);
    }

    return Fraction(num / g, den / g);
}

bool fraction_equal(const Fraction& a, const Fraction& b) {
    return a.num == b.num && a.den == b.den;
}

double fraction_abs_distance(const Fraction& a, long long target) {
    long double value = static_cast<long double>(a.num) /
                        static_cast<long double>(a.den);
    long double diff = std::fabs(value - static_cast<long double>(target));
    return static_cast<double>(diff);
}

std::string fraction_to_string(const Fraction& f) {
    if (f.den == 1) {
        return std::to_string(f.num);
    }
    return std::to_string(f.num) + "/" + std::to_string(f.den);
}

State make_initial_state(const std::vector<int>& digits) {
    State state;
    state.reserve(digits.size());

    for (std::size_t i = 0; i < digits.size(); ++i) {
        int d = digits[i];
        std::string text(1, static_cast<char>('0' + d));
        state.push_back(Fragment(make_fraction(d), text, true, text));
    }

    return state;
}

bool is_goal(const State& state, long long target) {
    return state.size() == 1 &&
           state[0].value.den == 1 &&
           state[0].value.num == target;
}

static Fraction add_fraction(const Fraction& a, const Fraction& b) {
    return make_fraction(a.num * b.den + b.num * a.den,
                         a.den * b.den);
}

static Fraction sub_fraction(const Fraction& a, const Fraction& b) {
    return make_fraction(a.num * b.den - b.num * a.den,
                         a.den * b.den);
}

static Fraction mul_fraction(const Fraction& a, const Fraction& b) {
    return make_fraction(a.num * b.num, a.den * b.den);
}

static Fraction div_fraction(const Fraction& a, const Fraction& b) {
    if (b.num == 0) {
        throw std::runtime_error("division by zero");
    }
    return make_fraction(a.num * b.den, a.den * b.num);
}

static State combine_at(const State& state,
                        std::size_t index,
                        const Fragment& merged) {
    State next;
    next.reserve(state.size() - 1);

    for (std::size_t i = 0; i < index; ++i) {
        next.push_back(state[i]);
    }

    next.push_back(merged);

    for (std::size_t i = index + 2; i < state.size(); ++i) {
        next.push_back(state[i]);
    }

    return next;
}

std::vector<State> get_successors(const State& state) {
    std::vector<State> result;

    if (state.size() < 2) {
        return result;
    }

    result.reserve((state.size() - 1) * 5);

    // Only neighbouring fragments are combined, therefore the original
    // order of digits is never changed.
    for (std::size_t i = 0; i + 1 < state.size(); ++i) {
        const Fragment& a = state[i];
        const Fragment& b = state[i + 1];

        result.push_back(combine_at(
            state, i,
            Fragment(add_fraction(a.value, b.value),
                     "(" + a.expr + "+" + b.expr + ")", false, "")));

        result.push_back(combine_at(
            state, i,
            Fragment(sub_fraction(a.value, b.value),
                     "(" + a.expr + "-" + b.expr + ")", false, "")));

        result.push_back(combine_at(
            state, i,
            Fragment(mul_fraction(a.value, b.value),
                     "(" + a.expr + "*" + b.expr + ")", false, "")));

        if (b.value.num != 0) {
            result.push_back(combine_at(
                state, i,
                Fragment(div_fraction(a.value, b.value),
                         "(" + a.expr + "/" + b.expr + ")", false, "")));
        }

        // No sign between two original/concatenated digit fragments means
        // they are digits of one number, for example 1 and 1 -> 11.
        if (a.pure_number && b.pure_number) {
            std::string joined = a.digits + b.digits;
            long long value = 0;
            std::stringstream ss(joined);
            ss >> value;

            result.push_back(combine_at(
                state, i,
                Fragment(make_fraction(value), joined, true, joined)));
        }
    }

    return result;
}

std::string state_key(const State& state) {
    std::ostringstream out;

    for (std::size_t i = 0; i < state.size(); ++i) {
        const Fragment& fragment = state[i];
        out << fragment.value.num << '/' << fragment.value.den << ':';

        if (fragment.pure_number) {
            out << 'P' << fragment.digits;
        } else {
            out << 'E';
        }

        out << '|';
    }

    return out.str();
}
