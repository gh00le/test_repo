#include "interface.h"

std::vector<int> parse_digits(const std::string& input) {
    std::stringstream ss(input);
    std::vector<int> digits;
    int digit;

    while (ss >> digit) {
        if (digit < 0 || digit > 9) {
            throw std::runtime_error("Each value must be one digit from 0 to 9");
        }
        digits.push_back(digit);
    }

    if (digits.empty() || digits.size() > 6) {
        throw std::runtime_error("The number of digits N must be from 1 to 6");
    }

    return digits;
}

std::string digits_to_string(const std::vector<int>& digits) {
    std::ostringstream out;
    out << '[';

    for (std::size_t i = 0; i < digits.size(); ++i) {
        if (i != 0) {
            out << ',';
        }
        out << digits[i];
    }

    out << ']';
    return out.str();
}
