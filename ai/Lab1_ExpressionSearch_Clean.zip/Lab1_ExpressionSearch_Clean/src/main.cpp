#include "ai.h"
#include "interface.h"

#include <iomanip>
#include <limits>

struct TestCase {
    std::vector<int> digits;
    long long target;

    TestCase(const std::vector<int>& d, long long k)
        : digits(d), target(k) {}
};

static void print_result(const std::string& algorithm,
                         int depth_limit,
                         const SearchResult& result) {
    std::cout << "\nAlgorithm: " << algorithm << '\n';

    if (depth_limit >= 0) {
        std::cout << "Depth limit: " << depth_limit << '\n';
    }

    std::cout << "Solution found: " << (result.found ? "yes" : "no") << '\n';
    std::cout << "Expanded states: " << result.expanded << '\n';
    std::cout << "Execution time: " << std::fixed << std::setprecision(6)
              << result.elapsed_ms << " ms\n";
    std::cout << "Solution length: " << result.solution_length << '\n';

    if (result.found) {
        std::cout << "Expression: " << result.expression << '\n';
    }
}

static void print_table_row(int case_number,
                            const TestCase& test,
                            const std::string& algorithm,
                            int depth_limit,
                            const SearchResult& result) {
    std::cout << case_number << '\t'
              << digits_to_string(test.digits) << '\t'
              << test.target << '\t'
              << algorithm << '\t';

    if (depth_limit >= 0) {
        std::cout << depth_limit;
    } else {
        std::cout << '-';
    }

    std::cout << '\t'
              << (result.found ? "yes" : "no") << '\t'
              << result.expanded << '\t'
              << std::fixed << std::setprecision(6)
              << result.elapsed_ms << '\t'
              << result.solution_length << '\t'
              << result.expression << '\n';
}

static void run_lab_tests() {
    std::vector<TestCase> tests;
    tests.push_back(TestCase(std::vector<int>{3, 2, 1, 1, 5}, 36));
    tests.push_back(TestCase(std::vector<int>{1, 2, 5, 2, 5}, 100));
    tests.push_back(TestCase(std::vector<int>{1, 0, 2, 4, 2}, 512));
    tests.push_back(TestCase(std::vector<int>{8, 2, 3, 1, 1}, 12));
    tests.push_back(TestCase(std::vector<int>{9, 1, 2, 3, 4}, 15));

    std::cout << "case\tdigits\ttarget\talgorithm\tlimit\tfound\texpanded\tms\tlength\texpression\n";

    for (std::size_t i = 0; i < tests.size(); ++i) {
        const TestCase& test = tests[i];
        int limit = static_cast<int>(test.digits.size()) - 1;

        print_table_row(static_cast<int>(i) + 1, test, "BFS", -1,
                        BFS_solve(test.digits, test.target));

        print_table_row(static_cast<int>(i) + 1, test, "DLS", limit,
                        DLS_solve(test.digits, test.target, limit));

        print_table_row(static_cast<int>(i) + 1, test, "BEST-H1", -1,
                        BEST_solve(test.digits, test.target, 1));

        print_table_row(static_cast<int>(i) + 1, test, "BEST-H2", -1,
                        BEST_solve(test.digits, test.target, 2));
    }
}

static std::vector<int> read_digits() {
    while (true) {
        std::cout << "Enter 1..6 digits separated by spaces\n"
                  << "Example: 3 2 1 1 5\n> ";

        std::string line;
        std::getline(std::cin, line);

        try {
            return parse_digits(line);
        } catch (const std::exception& e) {
            std::cout << "Input error: " << e.what() << "\n\n";
        }
    }
}

static long long read_target() {
    while (true) {
        std::cout << "Enter target k:\n> ";

        long long target;
        if (std::cin >> target) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return target;
        }

        std::cout << "Input error. k must be an integer.\n\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

static int read_int(const std::string& prompt) {
    while (true) {
        std::cout << prompt << "\n> ";

        int value;
        if (std::cin >> value) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }

        std::cout << "Input error. Enter an integer.\n\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

static void run_custom_test() {
    std::vector<int> digits = read_digits();
    long long target = read_target();

    std::cout << "\nInitial state: " << digits_to_string(digits)
              << ", target k = " << target << "\n\n";

    std::cout << "1 - BFS\n"
              << "2 - DLS\n"
              << "3 - Best-First, heuristic H1\n"
              << "4 - Best-First, heuristic H2\n"
              << "5 - Run all algorithms\n";

    int choice = read_int("Choose algorithm:");
    int natural_limit = static_cast<int>(digits.size()) - 1;

    if (choice == 1) {
        print_result("BFS", -1, BFS_solve(digits, target));
    } else if (choice == 2) {
        int limit = read_int("Enter DLS depth limit (recommended N-1 = " +
                             std::to_string(natural_limit) + "):");
        print_result("DLS", limit, DLS_solve(digits, target, limit));
    } else if (choice == 3) {
        print_result("Best-First H1", -1,
                     BEST_solve(digits, target, 1));
    } else if (choice == 4) {
        print_result("Best-First H2", -1,
                     BEST_solve(digits, target, 2));
    } else if (choice == 5) {
        print_result("BFS", -1, BFS_solve(digits, target));
        print_result("DLS", natural_limit,
                     DLS_solve(digits, target, natural_limit));
        print_result("Best-First H1", -1,
                     BEST_solve(digits, target, 1));
        print_result("Best-First H2", -1,
                     BEST_solve(digits, target, 2));
    } else {
        std::cout << "Unknown menu item.\n";
    }
}

int main() {
    std::cout << "Laboratory work #1: state-space search\n";
    std::cout << "Task: arithmetic expression from digits\n";
    std::cout << "Operations: +, -, *, /, parentheses, digit concatenation\n\n";

    while (true) {
        std::cout << "1 - Run the 5 test cases from the report\n"
                  << "2 - Enter your own digits and target\n"
                  << "0 - Exit\n";

        int choice = read_int("Choose mode:");
        std::cout << '\n';

        if (choice == 0) {
            break;
        } else if (choice == 1) {
            run_lab_tests();
        } else if (choice == 2) {
            run_custom_test();
        } else {
            std::cout << "Unknown menu item.\n";
        }

        std::cout << "\n----------------------------------------\n\n";
    }

    return 0;
}
