#include "ai.h"
#include "game8.h"

struct SearchNode {
    State state;
    int depth;

    SearchNode(const State& s, int d) : state(s), depth(d) {}
};

SearchResult BFS_solve(const std::vector<int>& digits, long long target) {
    std::chrono::steady_clock::time_point started =
        std::chrono::steady_clock::now();

    SearchResult result;
    State initial = make_initial_state(digits);

    std::queue<SearchNode> open;
    std::unordered_set<std::string> visited;

    open.push(SearchNode(initial, 0));
    visited.insert(state_key(initial));

    while (!open.empty()) {
        SearchNode current = open.front();
        open.pop();

        ++result.expanded;

        if (is_goal(current.state, target)) {
            result.found = true;
            result.expression = current.state[0].expr;
            result.solution_length = current.depth;
            break;
        }

        std::vector<State> successors = get_successors(current.state);
        for (std::size_t i = 0; i < successors.size(); ++i) {
            const State& next = successors[i];
            std::string key = state_key(next);

            if (visited.insert(key).second) {
                open.push(SearchNode(next, current.depth + 1));
            }
        }
    }

    std::chrono::steady_clock::time_point finished =
        std::chrono::steady_clock::now();
    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(finished - started).count();

    return result;
}

static bool dls_recursive(const State& state,
                          long long target,
                          int depth,
                          int limit,
                          std::unordered_set<std::string>& path_states,
                          SearchResult& result,
                          std::string& solution_expression,
                          int& solution_depth) {
    ++result.expanded;

    if (is_goal(state, target)) {
        solution_expression = state[0].expr;
        solution_depth = depth;
        return true;
    }

    if (depth >= limit) {
        return false;
    }

    std::vector<State> successors = get_successors(state);

    for (std::size_t i = 0; i < successors.size(); ++i) {
        const State& next = successors[i];
        std::string key = state_key(next);

        if (path_states.find(key) != path_states.end()) {
            continue;
        }

        path_states.insert(key);

        if (dls_recursive(next, target, depth + 1, limit,
                          path_states, result,
                          solution_expression, solution_depth)) {
            return true;
        }

        // Remove from the current DFS path so another branch may use it.
        path_states.erase(key);
    }

    return false;
}

SearchResult DLS_solve(const std::vector<int>& digits,
                       long long target,
                       int limit) {
    std::chrono::steady_clock::time_point started =
        std::chrono::steady_clock::now();

    SearchResult result;

    if (limit < 0) {
        result.elapsed_ms = 0.0;
        return result;
    }

    State initial = make_initial_state(digits);
    std::unordered_set<std::string> path_states;
    path_states.insert(state_key(initial));

    std::string expression;
    int depth = -1;

    if (dls_recursive(initial, target, 0, limit,
                      path_states, result, expression, depth)) {
        result.found = true;
        result.expression = expression;
        result.solution_length = depth;
    }

    std::chrono::steady_clock::time_point finished =
        std::chrono::steady_clock::now();
    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(finished - started).count();

    return result;
}

// H1: distance from target to the closest current fragment value.
double heuristic_distance(const State& state, long long target) {
    double best = std::numeric_limits<double>::infinity();

    for (std::size_t i = 0; i < state.size(); ++i) {
        double distance = fraction_abs_distance(state[i].value, target);
        if (distance < best) {
            best = distance;
        }
    }

    return best;
}

// H2: one-step look-ahead. We generate all immediate successors and use
// the best H1 value among them.
double heuristic_one_step(const State& state, long long target) {
    if (state.size() <= 1) {
        return heuristic_distance(state, target);
    }

    double best = std::numeric_limits<double>::infinity();
    std::vector<State> successors = get_successors(state);

    for (std::size_t i = 0; i < successors.size(); ++i) {
        double h = heuristic_distance(successors[i], target);
        if (h < best) {
            best = h;
        }
    }

    return best;
}

struct BestItem {
    double heuristic;
    int remaining_steps;
    std::size_t order;
    State state;

    BestItem(double h, int rem, std::size_t ord, const State& s)
        : heuristic(h), remaining_steps(rem), order(ord), state(s) {}
};

struct BestItemCompare {
    bool operator()(const BestItem& a, const BestItem& b) const {
        if (a.heuristic != b.heuristic) {
            return a.heuristic > b.heuristic;
        }
        if (a.remaining_steps != b.remaining_steps) {
            return a.remaining_steps > b.remaining_steps;
        }
        return a.order > b.order;
    }
};

SearchResult BEST_solve(const std::vector<int>& digits,
                        long long target,
                        int heuristic_id) {
    std::chrono::steady_clock::time_point started =
        std::chrono::steady_clock::now();

    SearchResult result;
    State initial = make_initial_state(digits);

    std::priority_queue<BestItem,
                        std::vector<BestItem>,
                        BestItemCompare> open;
    std::unordered_set<std::string> visited;

    std::size_t order = 0;

    double first_h = (heuristic_id == 2)
        ? heuristic_one_step(initial, target)
        : heuristic_distance(initial, target);

    open.push(BestItem(first_h,
                       static_cast<int>(initial.size()) - 1,
                       order++, initial));
    visited.insert(state_key(initial));

    const int initial_size = static_cast<int>(initial.size());

    while (!open.empty()) {
        BestItem current = open.top();
        open.pop();

        ++result.expanded;

        int depth = initial_size - static_cast<int>(current.state.size());

        if (is_goal(current.state, target)) {
            result.found = true;
            result.expression = current.state[0].expr;
            result.solution_length = depth;
            break;
        }

        std::vector<State> successors = get_successors(current.state);

        for (std::size_t i = 0; i < successors.size(); ++i) {
            const State& next = successors[i];
            std::string key = state_key(next);

            if (!visited.insert(key).second) {
                continue;
            }

            double h = (heuristic_id == 2)
                ? heuristic_one_step(next, target)
                : heuristic_distance(next, target);

            open.push(BestItem(h,
                               static_cast<int>(next.size()) - 1,
                               order++, next));
        }
    }

    std::chrono::steady_clock::time_point finished =
        std::chrono::steady_clock::now();
    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(finished - started).count();

    return result;
}
