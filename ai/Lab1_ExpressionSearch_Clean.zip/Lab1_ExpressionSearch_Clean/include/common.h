#ifndef COMMON_H
#define COMMON_H

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <iostream>
#include <limits>
#include <queue>
#include <sstream>
#include <stdexcept>
#include <string>
#include <tuple>
#include <unordered_set>
#include <utility>
#include <vector>

// Exact rational number. This avoids floating-point errors during search.
struct Fraction {
    long long num;
    long long den;

    Fraction(long long n = 0, long long d = 1) : num(n), den(d) {}
};

// One fragment of the expression.
// Example: value = 6, expr = "(3*2)".
struct Fragment {
    Fraction value;
    std::string expr;

    // true only when the fragment was obtained only by concatenating digits.
    // This is needed because 1 and 1 may be concatenated into 11,
    // but (3+2) and 1 may not be concatenated.
    bool pure_number;
    std::string digits;

    Fragment(const Fraction& v = Fraction(),
             const std::string& e = "",
             bool pure = false,
             const std::string& d = "")
        : value(v), expr(e), pure_number(pure), digits(d) {}
};

using State = std::vector<Fragment>;

struct SearchResult {
    bool found;
    std::string expression;
    int solution_length;
    std::size_t expanded;
    double elapsed_ms;

    SearchResult()
        : found(false), expression(""), solution_length(-1),
          expanded(0), elapsed_ms(0.0) {}
};

#endif
