#ifndef GAME8_H
#define GAME8_H

#include "common.h"

Fraction make_fraction(long long num, long long den = 1);
bool fraction_equal(const Fraction& a, const Fraction& b);
double fraction_abs_distance(const Fraction& a, long long target);
std::string fraction_to_string(const Fraction& f);

State make_initial_state(const std::vector<int>& digits);
bool is_goal(const State& state, long long target);
std::vector<State> get_successors(const State& state);
std::string state_key(const State& state);

#endif
