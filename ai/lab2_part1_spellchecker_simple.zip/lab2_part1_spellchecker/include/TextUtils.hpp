#pragma once

#include <string>

namespace spellchecker {

bool isEnglishLetter(char ch);
std::string toLowerAscii(std::string value);
std::string toUpperAscii(std::string value);
std::string applyCasePattern(const std::string& original, std::string replacement);
std::string readWholeFile(const std::string& path);

} // namespace spellchecker
