#pragma once

#include <string>
#include <vector>

namespace spellchecker {

struct EditOperation {
    enum class Type {
        Insert,
        Delete,
        Replace
    };

    Type type;
    char from = '\0';
    char to = '\0';
};

class Levenshtein {
public:
    static constexpr int INSERT_COST = 1;
    static constexpr int DELETE_COST = 1;
    // По методичке лабораторной работы замена имеет стоимость 2.
    static constexpr int REPLACE_COST = 2;

    static int boundedDistance(
        const std::string& first,
        const std::string& second,
        int limit);

    static std::vector<EditOperation> restoreOperations(
        const std::string& first,
        const std::string& second);
};

} // namespace spellchecker
