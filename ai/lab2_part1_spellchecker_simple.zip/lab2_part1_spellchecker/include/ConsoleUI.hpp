#pragma once

#include "SpellChecker.hpp"

#include <string>
#include <vector>

namespace spellchecker {

std::string operationToString(const EditOperation& operation);
void printCorrectionReport(const std::vector<CorrectionInfo>& corrections);
int readMaxDistance();
std::string readInputText();

} // namespace spellchecker
