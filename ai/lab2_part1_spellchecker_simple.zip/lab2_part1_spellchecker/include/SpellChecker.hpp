#pragma once

#include "Levenshtein.hpp"

#include <cstddef>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace spellchecker {

struct SearchResult {
    bool found = false;
    int distance = -1;
    std::vector<std::string> candidates;
    std::string chosen;
    std::vector<EditOperation> operations;
};

struct CorrectionInfo {
    std::string original;
    std::string replacement;
    int distance = -1;
    std::vector<std::string> candidates;
    std::vector<EditOperation> operations;
};

class SpellChecker {
public:
    void loadDictionary(const std::string& path);

    std::size_t loadedWords() const noexcept;
    std::size_t skippedWords() const noexcept;

    bool contains(const std::string& lowerWord) const;

    std::unordered_map<std::string, std::size_t> buildDocumentFrequency(
        const std::string& text) const;

    SearchResult findCorrection(
        const std::string& lowerWord,
        int maxDistance,
        const std::unordered_map<std::string, std::size_t>& frequency) const;

    std::string correctText(
        const std::string& text,
        int maxDistance,
        std::vector<CorrectionInfo>& corrections,
        std::size_t& unknownWithoutReplacement) const;

private:
    std::unordered_set<std::string> dictionary_;
    std::unordered_map<std::size_t, std::vector<std::string>> byLength_;
    std::size_t loadedWords_ = 0;
    std::size_t skippedWords_ = 0;

    static std::size_t getFrequency(
        const std::string& word,
        const std::unordered_map<std::string, std::size_t>& frequency);
};

} // namespace spellchecker
