#include "Levenshtein.hpp"

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace spellchecker {

int Levenshtein::boundedDistance(
    const std::string& first,
    const std::string& second,
    int limit) {

    const int n = static_cast<int>(first.size());
    const int m = static_cast<int>(second.size());

    if (std::abs(n - m) > limit) {
        return limit + 1;
    }

    const int infinity = limit + 1;
    std::vector<int> previous(m + 1, infinity);
    std::vector<int> current(m + 1, infinity);

    for (int j = 0; j <= std::min(m, limit); ++j) {
        previous[j] = j * INSERT_COST;
    }

    for (int i = 1; i <= n; ++i) {
        std::fill(current.begin(), current.end(), infinity);
        if (i <= limit) {
            current[0] = i * DELETE_COST;
        }

        const int left = std::max(1, i - limit);
        const int right = std::min(m, i + limit);

        for (int j = left; j <= right; ++j) {
            const int deletion = previous[j] >= infinity
                ? infinity
                : previous[j] + DELETE_COST;

            const int insertion = current[j - 1] >= infinity
                ? infinity
                : current[j - 1] + INSERT_COST;

            const int replaceCost = first[i - 1] == second[j - 1]
                ? 0
                : REPLACE_COST;

            const int replacement = previous[j - 1] >= infinity
                ? infinity
                : previous[j - 1] + replaceCost;

            current[j] = std::min({deletion, insertion, replacement, infinity});
        }

        previous.swap(current);
    }

    return previous[m] <= limit ? previous[m] : limit + 1;
}

std::vector<EditOperation> Levenshtein::restoreOperations(
    const std::string& first,
    const std::string& second) {

    const std::size_t n = first.size();
    const std::size_t m = second.size();
    std::vector<std::vector<int>> dp(n + 1, std::vector<int>(m + 1));

    for (std::size_t i = 0; i <= n; ++i) {
        dp[i][0] = static_cast<int>(i) * DELETE_COST;
    }
    for (std::size_t j = 0; j <= m; ++j) {
        dp[0][j] = static_cast<int>(j) * INSERT_COST;
    }

    for (std::size_t i = 1; i <= n; ++i) {
        for (std::size_t j = 1; j <= m; ++j) {
            const int cost = first[i - 1] == second[j - 1] ? 0 : REPLACE_COST;
            dp[i][j] = std::min({
                dp[i - 1][j] + DELETE_COST,
                dp[i][j - 1] + INSERT_COST,
                dp[i - 1][j - 1] + cost
            });
        }
    }

    std::vector<EditOperation> reversed;
    std::size_t i = n;
    std::size_t j = m;

    while (i > 0 || j > 0) {
        if (i > 0 && j > 0 &&
            first[i - 1] == second[j - 1] &&
            dp[i][j] == dp[i - 1][j - 1]) {
            --i;
            --j;
            continue;
        }

        if (i > 0 && j > 0 &&
            dp[i][j] == dp[i - 1][j - 1] + REPLACE_COST) {
            reversed.push_back({
                EditOperation::Type::Replace,
                first[i - 1],
                second[j - 1]
            });
            --i;
            --j;
        } else if (i > 0 && dp[i][j] == dp[i - 1][j] + DELETE_COST) {
            reversed.push_back({
                EditOperation::Type::Delete,
                first[i - 1],
                '\0'
            });
            --i;
        } else if (j > 0 && dp[i][j] == dp[i][j - 1] + INSERT_COST) {
            reversed.push_back({
                EditOperation::Type::Insert,
                '\0',
                second[j - 1]
            });
            --j;
        } else {
            throw std::logic_error("Failed to restore Levenshtein path.");
        }
    }

    std::reverse(reversed.begin(), reversed.end());
    return reversed;
}

} // namespace spellchecker
