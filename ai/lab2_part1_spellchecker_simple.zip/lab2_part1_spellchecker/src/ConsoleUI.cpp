#include "ConsoleUI.hpp"

#include "TextUtils.hpp"

#include <algorithm>
#include <iostream>
#include <sstream>
#include <stdexcept>

namespace spellchecker {

std::string operationToString(const EditOperation& operation) {
    std::ostringstream out;

    switch (operation.type) {
        case EditOperation::Type::Insert:
            out << "insert '" << operation.to << "'";
            break;
        case EditOperation::Type::Delete:
            out << "delete '" << operation.from << "'";
            break;
        case EditOperation::Type::Replace:
            out << "replace '" << operation.from << "' -> '" << operation.to << "'";
            break;
    }

    return out.str();
}

void printCorrectionReport(const std::vector<CorrectionInfo>& corrections) {
    if (corrections.empty()) {
        std::cout << "\nNo corrections were made.\n";
        return;
    }

    std::cout << "\nCorrections:\n";
    for (std::size_t i = 0; i < corrections.size(); ++i) {
        const CorrectionInfo& correction = corrections[i];

        std::cout << "  " << (i + 1) << ". "
                  << correction.original << " -> " << correction.replacement
                  << "  (distance = " << correction.distance << ")\n";

        std::cout << "     minimum-distance candidates ("
                  << correction.candidates.size() << "): ";

        const std::size_t shown = std::min<std::size_t>(correction.candidates.size(), 12);
        for (std::size_t k = 0; k < shown; ++k) {
            if (k != 0) {
                std::cout << ", ";
            }
            std::cout << correction.candidates[k];
        }
        if (correction.candidates.size() > shown) {
            std::cout << ", ...";
        }
        std::cout << '\n';

        if (!correction.operations.empty()) {
            std::cout << "     edit path: ";
            for (std::size_t k = 0; k < correction.operations.size(); ++k) {
                if (k != 0) {
                    std::cout << "; ";
                }
                std::cout << operationToString(correction.operations[k]);
            }
            std::cout << '\n';
        }
    }
}

int readMaxDistance() {
    std::cout << "Maximum edit distance [default 2]: ";

    std::string line;
    std::getline(std::cin, line);
    if (line.empty()) {
        return 2;
    }

    try {
        const int value = std::stoi(line);
        if (value < 0 || value > 10) {
            throw std::out_of_range("distance");
        }
        return value;
    } catch (...) {
        throw std::runtime_error("Maximum distance must be an integer from 0 to 10.");
    }
}

std::string readInputText() {
    std::cout << "Input mode: 1 - keyboard, 2 - file [default 1]: ";

    std::string mode;
    std::getline(std::cin, mode);

    if (mode.empty() || mode == "1") {
        std::cout << "Enter one line of English text:\n> ";
        std::string text;
        std::getline(std::cin, text);
        return text;
    }

    if (mode == "2") {
        std::cout << "Input file path: ";
        std::string path;
        std::getline(std::cin, path);
        return readWholeFile(path);
    }

    throw std::runtime_error("Unknown input mode.");
}

} // namespace spellchecker
