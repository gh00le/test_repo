#include "SpellChecker.hpp"

#include "TextUtils.hpp"

#include <algorithm>
#include <fstream>
#include <stdexcept>
#include <utility>

namespace spellchecker {

void SpellChecker::loadDictionary(const std::string& path) {
    std::ifstream input(path);
    if (!input) {
        throw std::runtime_error("Cannot open dictionary: " + path);
    }

    dictionary_.clear();
    byLength_.clear();
    loadedWords_ = 0;
    skippedWords_ = 0;

    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        if (line.empty()) {
            continue;
        }

        std::string word = toLowerAscii(line);
        const bool onlyEnglishLetters = std::all_of(
            word.begin(),
            word.end(),
            isEnglishLetter);

        if (!onlyEnglishLetters) {
            ++skippedWords_;
            continue;
        }

        if (dictionary_.insert(word).second) {
            byLength_[word.size()].push_back(word);
            ++loadedWords_;
        }
    }

    if (dictionary_.empty()) {
        throw std::runtime_error("Dictionary contains no English alphabetic words.");
    }

    for (auto& [length, bucket] : byLength_) {
        (void)length;
        std::sort(bucket.begin(), bucket.end());
    }
}

std::size_t SpellChecker::loadedWords() const noexcept {
    return loadedWords_;
}

std::size_t SpellChecker::skippedWords() const noexcept {
    return skippedWords_;
}

bool SpellChecker::contains(const std::string& lowerWord) const {
    return dictionary_.find(lowerWord) != dictionary_.end();
}

std::unordered_map<std::string, std::size_t> SpellChecker::buildDocumentFrequency(
    const std::string& text) const {

    std::unordered_map<std::string, std::size_t> frequency;
    std::size_t i = 0;

    while (i < text.size()) {
        if (!isEnglishLetter(text[i])) {
            ++i;
            continue;
        }

        const std::size_t start = i;
        while (i < text.size() && isEnglishLetter(text[i])) {
            ++i;
        }

        const std::string word = toLowerAscii(text.substr(start, i - start));
        if (contains(word)) {
            ++frequency[word];
        }
    }

    return frequency;
}

SearchResult SpellChecker::findCorrection(
    const std::string& lowerWord,
    int maxDistance,
    const std::unordered_map<std::string, std::size_t>& frequency) const {

    SearchResult result;
    if (maxDistance < 0) {
        return result;
    }

    const std::size_t wordLength = lowerWord.size();
    const std::size_t distance = static_cast<std::size_t>(maxDistance);
    const std::size_t minLength = wordLength > distance ? wordLength - distance : 0;
    const std::size_t maxLength = wordLength + distance;

    int bestDistance = maxDistance + 1;

    // Индексация по длине: рассматриваем только слова, длина которых
    // может дать расстояние не больше maxDistance.
    for (std::size_t length = minLength; length <= maxLength; ++length) {
        const auto bucketIt = byLength_.find(length);
        if (bucketIt == byLength_.end()) {
            continue;
        }

        for (const std::string& candidate : bucketIt->second) {
            const int currentLimit = std::min(maxDistance, bestDistance);
            const int candidateDistance = Levenshtein::boundedDistance(
                lowerWord,
                candidate,
                currentLimit);

            if (candidateDistance > maxDistance) {
                continue;
            }

            if (candidateDistance < bestDistance) {
                bestDistance = candidateDistance;
                result.candidates.clear();
                result.candidates.push_back(candidate);
            } else if (candidateDistance == bestDistance) {
                result.candidates.push_back(candidate);
            }
        }
    }

    if (result.candidates.empty()) {
        return result;
    }

    result.found = true;
    result.distance = bestDistance;
    std::sort(result.candidates.begin(), result.candidates.end());

    // Политика выбора среди кандидатов с одинаковым расстоянием:
    // 1) максимальная частота в текущем тексте;
    // 2) при равной частоте — лексикографически первое слово.
    result.chosen = result.candidates.front();
    std::size_t bestFrequency = getFrequency(result.chosen, frequency);

    for (const std::string& candidate : result.candidates) {
        const std::size_t candidateFrequency = getFrequency(candidate, frequency);
        if (candidateFrequency > bestFrequency ||
            (candidateFrequency == bestFrequency && candidate < result.chosen)) {
            result.chosen = candidate;
            bestFrequency = candidateFrequency;
        }
    }

    result.operations = Levenshtein::restoreOperations(lowerWord, result.chosen);
    return result;
}

std::string SpellChecker::correctText(
    const std::string& text,
    int maxDistance,
    std::vector<CorrectionInfo>& corrections,
    std::size_t& unknownWithoutReplacement) const {

    auto frequency = buildDocumentFrequency(text);
    std::string output;
    output.reserve(text.size());

    std::size_t i = 0;
    while (i < text.size()) {
        if (!isEnglishLetter(text[i])) {
            output.push_back(text[i]);
            ++i;
            continue;
        }

        const std::size_t start = i;
        while (i < text.size() && isEnglishLetter(text[i])) {
            ++i;
        }

        const std::string original = text.substr(start, i - start);
        const std::string lower = toLowerAscii(original);

        if (contains(lower)) {
            output += original;
            ++frequency[lower];
            continue;
        }

        SearchResult result = findCorrection(lower, maxDistance, frequency);
        if (!result.found) {
            output += original;
            ++unknownWithoutReplacement;
            continue;
        }

        const std::string replacement = applyCasePattern(original, result.chosen);
        output += replacement;
        ++frequency[result.chosen];

        corrections.push_back({
            original,
            replacement,
            result.distance,
            std::move(result.candidates),
            std::move(result.operations)
        });
    }

    return output;
}

std::size_t SpellChecker::getFrequency(
    const std::string& word,
    const std::unordered_map<std::string, std::size_t>& frequency) {

    const auto it = frequency.find(word);
    return it == frequency.end() ? 0 : it->second;
}

} // namespace spellchecker
