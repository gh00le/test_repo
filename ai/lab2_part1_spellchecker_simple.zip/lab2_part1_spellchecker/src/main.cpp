#include "ConsoleUI.hpp"
#include "SpellChecker.hpp"

#include <chrono>
#include <exception>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

int main(int argc, char* argv[]) {
    try {
        std::ios::sync_with_stdio(false);
        std::cin.tie(nullptr);

        std::string dictionaryPath = "words_alpha.txt";
        if (argc >= 2) {
            dictionaryPath = argv[1];
        }

        spellchecker::SpellChecker checker;

        const auto loadStart = std::chrono::steady_clock::now();
        checker.loadDictionary(dictionaryPath);
        const auto loadEnd = std::chrono::steady_clock::now();

        std::cout << "Dictionary: " << dictionaryPath << '\n';
        std::cout << "Loaded English words: " << checker.loadedWords() << '\n';
        if (checker.skippedWords() > 0) {
            std::cout << "Skipped non-alphabetic entries: "
                      << checker.skippedWords() << '\n';
        }

        const int maxDistance = spellchecker::readMaxDistance();
        const std::string inputText = spellchecker::readInputText();

        std::vector<spellchecker::CorrectionInfo> corrections;
        std::size_t unknownWithoutReplacement = 0;

        const auto workStart = std::chrono::steady_clock::now();
        const std::string corrected = checker.correctText(
            inputText,
            maxDistance,
            corrections,
            unknownWithoutReplacement);
        const auto workEnd = std::chrono::steady_clock::now();

        const auto loadMs = std::chrono::duration<double, std::milli>(
            loadEnd - loadStart).count();
        const auto workMs = std::chrono::duration<double, std::milli>(
            workEnd - workStart).count();

        std::cout << "\nOriginal text:\n" << inputText << '\n';
        std::cout << "\nCorrected text:\n" << corrected << '\n';

        spellchecker::printCorrectionReport(corrections);

        std::cout << std::fixed << std::setprecision(3);
        std::cout << "\nStatistics:\n";
        std::cout << "  corrections: " << corrections.size() << '\n';
        std::cout << "  unknown words left unchanged: "
                  << unknownWithoutReplacement << '\n';
        std::cout << "  max distance: " << maxDistance << '\n';
        std::cout << "  dictionary loading time: " << loadMs << " ms\n";
        std::cout << "  spellchecking time: " << workMs << " ms\n";

        return 0;
    } catch (const std::exception& exception) {
        std::cerr << "Error: " << exception.what() << '\n';
        return 1;
    }
}
