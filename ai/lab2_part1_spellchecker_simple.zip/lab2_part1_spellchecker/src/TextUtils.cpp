#include "TextUtils.hpp"

#include <fstream>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace spellchecker {
namespace {

bool isAllUpper(const std::string& value) {
    bool hasLetter = false;
    for (char ch : value) {
        if (!isEnglishLetter(ch)) {
            continue;
        }

        hasLetter = true;
        if (ch >= 'a' && ch <= 'z') {
            return false;
        }
    }
    return hasLetter;
}

bool isTitleCase(const std::string& value) {
    if (value.empty() || !(value[0] >= 'A' && value[0] <= 'Z')) {
        return false;
    }

    for (std::size_t i = 1; i < value.size(); ++i) {
        if (isEnglishLetter(value[i]) && !(value[i] >= 'a' && value[i] <= 'z')) {
            return false;
        }
    }
    return true;
}

} // namespace

bool isEnglishLetter(char ch) {
    const unsigned char c = static_cast<unsigned char>(ch);
    return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
}

std::string toLowerAscii(std::string value) {
    for (char& ch : value) {
        const unsigned char c = static_cast<unsigned char>(ch);
        if (c >= 'A' && c <= 'Z') {
            ch = static_cast<char>(c - 'A' + 'a');
        }
    }
    return value;
}

std::string toUpperAscii(std::string value) {
    for (char& ch : value) {
        const unsigned char c = static_cast<unsigned char>(ch);
        if (c >= 'a' && c <= 'z') {
            ch = static_cast<char>(c - 'a' + 'A');
        }
    }
    return value;
}

std::string applyCasePattern(const std::string& original, std::string replacement) {
    if (isAllUpper(original)) {
        return toUpperAscii(std::move(replacement));
    }

    if (isTitleCase(original)) {
        replacement = toLowerAscii(std::move(replacement));
        if (!replacement.empty()) {
            replacement[0] = static_cast<char>(replacement[0] - 'a' + 'A');
        }
        return replacement;
    }

    return toLowerAscii(std::move(replacement));
}

std::string readWholeFile(const std::string& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        throw std::runtime_error("Cannot open input file: " + path);
    }

    std::ostringstream buffer;
    buffer << input.rdbuf();
    return buffer.str();
}

} // namespace spellchecker
