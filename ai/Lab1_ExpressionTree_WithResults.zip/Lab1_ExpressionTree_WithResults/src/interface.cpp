#include <interface.h>
#include <game8.h>
#include <fstream>

void print_state(const State& state) {
    std::cout << state_expression(state) << std::endl;
}

State parse_state(const std::string& input) {
    return make_initial_state(input);
}

void save_solution_steps(
    const std::string& filename,
    const std::string& algorithm,
    const std::string& digits,
    long long target,
    const std::vector<State>& solution,
    bool append
) {
    std::ios_base::openmode mode = std::ios::out;
    if (append) mode |= std::ios::app;

    std::ofstream file(filename.c_str(), mode);
    if (!file.is_open()) return;

    file << "Algorithm: " << algorithm << std::endl;
    file << "Digits: " << digits << std::endl;
    file << "Target: " << target << std::endl;

    if (solution.empty()) {
        file << "Solution not found" << std::endl << std::endl;
        return;
    }

    for (std::size_t i = 0; i < solution.size(); ++i) {
        file << "Step " << i << ": " << state_expression(solution[i]) << std::endl;
    }

    file << "Result: " << state_expression(solution.back()) << std::endl;
    file << std::endl;
}
