#include <ai.h>
#include <interface.h>
#include <game8.h>

struct TestCase {
    std::string digits;
    long long target;
};

struct TestResult {
    std::string digits;
    long long target;
    std::vector<State> bfs;
    std::vector<State> dls;
    std::vector<State> h1;
    std::vector<State> h2;
};

static void print_result(
    const std::string& algorithm,
    const std::vector<State>& solution,
    std::size_t expanded,
    double time_ms,
    int dls_limit
) {
    std::cout << algorithm << std::endl;
    std::cout << "Found: " << (solution.empty() ? "no" : "yes") << std::endl;
    std::cout << "Expanded: " << expanded << std::endl;
    std::cout << "Time: " << std::fixed << std::setprecision(4) << time_ms << " ms" << std::endl;

    if (dls_limit >= 0) {
        std::cout << "Depth limit: " << dls_limit << std::endl;
    }

    if (!solution.empty()) {
        std::cout << "Length: " << static_cast<int>(solution.size()) - 1 << std::endl;
        std::cout << "Expression: " << state_expression(solution.back()) << std::endl;
    }

    std::cout << std::endl;
}

static TestResult run_test(const std::string& digits, long long target) {
    set_target(target);
    State start = parse_state(digits);
    int limit = static_cast<int>(state_size(start)) - 1;

    TestResult result;
    result.digits = digits;
    result.target = target;

    std::cout << "Digits: " << digits << std::endl;
    std::cout << "Target: " << target << std::endl << std::endl;

    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    result.bfs = BFS_solve(start);
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    double bfs_time = std::chrono::duration<double, std::milli>(end - begin).count();
    print_result("BFS", result.bfs, get_last_expanded(), bfs_time, -1);

    begin = std::chrono::steady_clock::now();
    result.dls = DLS_solve(start, limit);
    end = std::chrono::steady_clock::now();
    double dls_time = std::chrono::duration<double, std::milli>(end - begin).count();
    print_result("DLS", result.dls, get_last_expanded(), dls_time, limit);

    begin = std::chrono::steady_clock::now();
    result.h1 = EST_solve(start, heuristic1);
    end = std::chrono::steady_clock::now();
    double h1_time = std::chrono::duration<double, std::milli>(end - begin).count();
    print_result("Heuristic H1", result.h1, get_last_expanded(), h1_time, -1);

    begin = std::chrono::steady_clock::now();
    result.h2 = EST_solve(start, heuristic2);
    end = std::chrono::steady_clock::now();
    double h2_time = std::chrono::duration<double, std::milli>(end - begin).count();
    print_result("Heuristic H2", result.h2, get_last_expanded(), h2_time, -1);

    return result;
}

static void save_all_results(const std::vector<TestResult>& results) {
    for (std::size_t i = 0; i < results.size(); ++i) {
        bool append = i != 0;

        save_solution_steps(
            "result_BFS.txt",
            "BFS",
            results[i].digits,
            results[i].target,
            results[i].bfs,
            append
        );

        save_solution_steps(
            "result_DLS.txt",
            "DLS",
            results[i].digits,
            results[i].target,
            results[i].dls,
            append
        );

        save_solution_steps(
            "result_H1.txt",
            "Heuristic H1",
            results[i].digits,
            results[i].target,
            results[i].h1,
            append
        );

        save_solution_steps(
            "result_H2.txt",
            "Heuristic H2",
            results[i].digits,
            results[i].target,
            results[i].h2,
            append
        );
    }

    std::cout << "Solution steps saved to result_BFS.txt, result_DLS.txt, result_H1.txt and result_H2.txt" << std::endl << std::endl;
}

static void ask_to_save(const std::vector<TestResult>& results) {
    int save = 0;
    std::cout << "Save solution steps to files?" << std::endl;
    std::cout << "1 - yes" << std::endl;
    std::cout << "0 - no" << std::endl;
    std::cout << "> ";
    std::cin >> save;
    std::cin.ignore(10000, '\n');
    std::cout << std::endl;

    if (save == 1) save_all_results(results);
}

int main() {
    TestCase tests[5] = {
        {"3 2 1 1 5", 36},
        {"1 2 3 4", 24},
        {"2 5 5", 50},
        {"9 1 2 3", 18},
        {"1 0 2 4 2", 512}
    };

    int mode = -1;

    while (mode != 0) {
        std::cout << "1 - prepared tests" << std::endl;
        std::cout << "2 - custom test" << std::endl;
        std::cout << "0 - exit" << std::endl;
        std::cout << "> ";
        std::cin >> mode;
        std::cin.ignore(10000, '\n');
        std::cout << std::endl;

        if (mode == 1) {
            std::vector<TestResult> results;

            for (int i = 0; i < 5; ++i) {
                std::cout << "Test " << i + 1 << std::endl;
                results.push_back(run_test(tests[i].digits, tests[i].target));
            }

            ask_to_save(results);
        }
        else if (mode == 2) {
            std::string digits;
            long long target;

            std::cout << "Enter digits separated by spaces: ";
            std::getline(std::cin, digits);

            State check = parse_state(digits);
            if (state_size(check) == 0 || state_size(check) > 6) {
                std::cout << "Number of digits must be from 1 to 6." << std::endl << std::endl;
                continue;
            }

            std::cout << "Enter target: ";
            std::cin >> target;
            std::cin.ignore(10000, '\n');
            std::cout << std::endl;

            std::vector<TestResult> results;
            results.push_back(run_test(digits, target));
            ask_to_save(results);
        }
    }

    return 0;
}
