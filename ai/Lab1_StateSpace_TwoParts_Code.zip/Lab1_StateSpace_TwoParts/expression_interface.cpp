#include "expression_interface.h"

std::string digits_to_string(const std::vector<int>& digits) {
    std::ostringstream out;

    out << '[';
    for (int i = 0; i < (int)digits.size(); i++) {
        if (i > 0) {
            out << ' ';
        }
        out << digits[i];
    }
    out << ']';

    return out.str();
}

void print_expression_result(const std::string& algorithm,
                             const ExpressionSearchResult& result,
                             int dls_limit) {
    std::cout << "---------------------------------------------\n";
    std::cout << "Algorithm: " << algorithm << '\n';

    if (dls_limit >= 0) {
        std::cout << "Depth limit: " << dls_limit << '\n';
    }

    std::cout << "Solution found: " << (result.found ? "yes" : "no") << '\n';
    std::cout << "Expanded states: " << result.expanded << '\n';
    std::cout << "Time: " << std::fixed << std::setprecision(4)
              << result.elapsed_ms << " ms\n";

    if (result.found) {
        std::cout << "Solution length: " << result.solution_length << '\n';
        std::cout << "Expression: " << result.expression << '\n';
    }
}
