#ifndef EXPRESSION_H
#define EXPRESSION_H

#include "common.h"

// ------------------------------------------------------------
// Fraction stores an exact rational number.
//
// We do not use double here because division can create values
// such as 1/3. With a fraction we can compare the final value
// with the target exactly, without rounding errors.
// ------------------------------------------------------------
struct Fraction {
    long long numerator;
    long long denominator;

    Fraction() {
        numerator = 0;
        denominator = 1;
    }

    Fraction(long long n, long long d) {
        numerator = n;
        denominator = d;
    }
};

// ------------------------------------------------------------
// ExprPart is one current part of the expression.
//
// Example state for digits 3 2 1 1 5:
// [3] [2] [11] [(5-1)]
//
// value        - exact numerical value of this part;
// text         - how the part looks as an expression;
// plain_number - true only while the part is made by joining
//                original digits without arithmetic operations.
// ------------------------------------------------------------
struct ExprPart {
    Fraction value;
    std::string text;
    bool plain_number;

    ExprPart() {
        plain_number = false;
    }
};

// One complete state is a list of neighboring expression parts.
typedef std::vector<ExprPart> ExpressionState;

// Result returned by one expression search algorithm.
struct ExpressionSearchResult {
    bool found;
    std::string expression;
    int solution_length;
    long long expanded;
    double elapsed_ms;

    ExpressionSearchResult() {
        found = false;
        expression = "";
        solution_length = -1;
        expanded = 0;
        elapsed_ms = 0.0;
    }
};

// Creates the initial state from the input digits.
ExpressionState make_expression_initial_state(const std::vector<int>& digits);

// Checks whether a state contains one final expression equal to target.
bool expression_is_goal(const ExpressionState& state, long long target);

// Creates all states that can be obtained by combining
// two neighboring parts with +, -, *, / or digit concatenation.
std::vector<ExpressionState> expression_get_successors(
    const ExpressionState& state);

// Creates a compact key for visited-state checking.
std::string expression_state_key(const ExpressionState& state);

// Converts a fraction to a long double value for heuristic calculations.
long double fraction_to_long_double(const Fraction& value);

#endif
