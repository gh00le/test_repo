#ifndef EXPRESSION_AI_H
#define EXPRESSION_AI_H

#include "expression.h"

// Breadth-First Search for the expression task.
ExpressionSearchResult expression_BFS_solve(
    const std::vector<int>& digits,
    long long target);

// Depth-Limited Search for the expression task.
ExpressionSearchResult expression_DLS_solve(
    const std::vector<int>& digits,
    long long target,
    int limit);

// Greedy Best-First Search.
// heuristic_id = 1 -> H1
// heuristic_id = 2 -> H2
ExpressionSearchResult expression_BEST_solve(
    const std::vector<int>& digits,
    long long target,
    int heuristic_id);

// H1: distance from target to the closest current part.
long double expression_heuristic1(const ExpressionState& state,
                                  long long target);

// H2: one-step look-ahead.
long double expression_heuristic2(const ExpressionState& state,
                                  long long target);

#endif
