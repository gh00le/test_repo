#include "expression_ai.h"

// A search node stores a state and its current depth.
struct ExpressionNode {
    ExpressionState state;
    int depth;

    ExpressionNode(const ExpressionState& s, int d) {
        state = s;
        depth = d;
    }
};

ExpressionSearchResult expression_BFS_solve(
    const std::vector<int>& digits,
    long long target) {

    ExpressionSearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    ExpressionState initial = make_expression_initial_state(digits);

    std::queue<ExpressionNode> open;
    std::unordered_set<std::string> visited;

    open.push(ExpressionNode(initial, 0));
    visited.insert(expression_state_key(initial));

    while (!open.empty()) {
        ExpressionNode current = open.front();
        open.pop();

        result.expanded++;

        if (expression_is_goal(current.state, target)) {
            result.found = true;
            result.expression = current.state[0].text;
            result.solution_length = current.depth;
            break;
        }

        std::vector<ExpressionState> successors =
            expression_get_successors(current.state);

        for (int i = 0; i < (int)successors.size(); i++) {
            std::string key = expression_state_key(successors[i]);

            if (visited.insert(key).second) {
                open.push(ExpressionNode(successors[i], current.depth + 1));
            }
        }
    }

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}

// Recursive helper for DLS.
static bool expression_dls_recursive(
    const ExpressionState& state,
    long long target,
    int depth,
    int limit,
    std::unordered_set<std::string>& visited,
    ExpressionSearchResult& result) {

    result.expanded++;

    if (expression_is_goal(state, target)) {
        result.found = true;
        result.expression = state[0].text;
        result.solution_length = depth;
        return true;
    }

    if (depth >= limit) {
        return false;
    }

    std::vector<ExpressionState> successors =
        expression_get_successors(state);

    for (int i = 0; i < (int)successors.size(); i++) {
        std::string key = expression_state_key(successors[i]);

        if (visited.insert(key).second) {
            if (expression_dls_recursive(successors[i],
                                         target,
                                         depth + 1,
                                         limit,
                                         visited,
                                         result)) {
                return true;
            }
        }
    }

    return false;
}

ExpressionSearchResult expression_DLS_solve(
    const std::vector<int>& digits,
    long long target,
    int limit) {

    ExpressionSearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    ExpressionState initial = make_expression_initial_state(digits);
    std::unordered_set<std::string> visited;
    visited.insert(expression_state_key(initial));

    expression_dls_recursive(initial,
                             target,
                             0,
                             limit,
                             visited,
                             result);

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}

long double expression_heuristic1(const ExpressionState& state,
                                  long long target) {
    long double best = std::numeric_limits<long double>::max();

    // We check every current part and find the one whose value
    // is closest to the required target.
    for (int i = 0; i < (int)state.size(); i++) {
        long double value = fraction_to_long_double(state[i].value);
        long double distance = std::fabs(value - (long double)target);

        if (distance < best) {
            best = distance;
        }
    }

    return best;
}

long double expression_heuristic2(const ExpressionState& state,
                                  long long target) {
    // If there is no next step, H2 has nothing to look ahead to.
    if (state.size() <= 1) {
        return expression_heuristic1(state, target);
    }

    std::vector<ExpressionState> successors =
        expression_get_successors(state);

    long double best = std::numeric_limits<long double>::max();

    // H2 looks one move ahead and asks:
    // "Which next state would have the best H1 value?"
    for (int i = 0; i < (int)successors.size(); i++) {
        long double value = expression_heuristic1(successors[i], target);
        if (value < best) {
            best = value;
        }
    }

    return best;
}

// Node used by Greedy Best-First Search.
struct BestExpressionNode {
    ExpressionState state;
    int depth;
    long double heuristic;

    BestExpressionNode(const ExpressionState& s,
                       int d,
                       long double h) {
        state = s;
        depth = d;
        heuristic = h;
    }
};

struct BestExpressionCompare {
    bool operator()(const BestExpressionNode& a,
                    const BestExpressionNode& b) const {
        // priority_queue normally returns the largest item first.
        // We need the smallest heuristic value first.
        if (a.heuristic != b.heuristic) {
            return a.heuristic > b.heuristic;
        }

        // If two states have the same heuristic value,
        // prefer the deeper one because it contains fewer parts.
        return a.depth < b.depth;
    }
};

ExpressionSearchResult expression_BEST_solve(
    const std::vector<int>& digits,
    long long target,
    int heuristic_id) {

    ExpressionSearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    ExpressionState initial = make_expression_initial_state(digits);

    std::priority_queue<BestExpressionNode,
                        std::vector<BestExpressionNode>,
                        BestExpressionCompare> open;

    std::unordered_set<std::string> visited;

    long double first_h;
    if (heuristic_id == 1) {
        first_h = expression_heuristic1(initial, target);
    } else {
        first_h = expression_heuristic2(initial, target);
    }

    open.push(BestExpressionNode(initial, 0, first_h));
    visited.insert(expression_state_key(initial));

    while (!open.empty()) {
        BestExpressionNode current = open.top();
        open.pop();

        result.expanded++;

        if (expression_is_goal(current.state, target)) {
            result.found = true;
            result.expression = current.state[0].text;
            result.solution_length = current.depth;
            break;
        }

        std::vector<ExpressionState> successors =
            expression_get_successors(current.state);

        for (int i = 0; i < (int)successors.size(); i++) {
            std::string key = expression_state_key(successors[i]);

            if (visited.insert(key).second) {
                long double h;

                if (heuristic_id == 1) {
                    h = expression_heuristic1(successors[i], target);
                } else {
                    h = expression_heuristic2(successors[i], target);
                }

                open.push(BestExpressionNode(successors[i],
                                             current.depth + 1,
                                             h));
            }
        }
    }

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}
