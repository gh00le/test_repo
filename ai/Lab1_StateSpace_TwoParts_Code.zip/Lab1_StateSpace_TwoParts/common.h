#ifndef COMMON_H
#define COMMON_H

#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <cmath>
#include <limits>

// ------------------------------------------------------------
// This file contains the main data structures of the program.
// Several .cpp files use these structures.
// ------------------------------------------------------------

// State is a "snapshot" of the task at one moment.
// We need to know two things:
// 1) which cells are already painted;
// 2) where the player is now.
struct State {
    std::vector<std::vector<int> > field; // Current field.
    int row;                              // Player row.
    int col;                              // Player column.

    State() {
        row = 0;
        col = 0;
    }
};

// SearchResult stores the result of one search algorithm.
// This is convenient because one function can return all useful data at once.
struct SearchResult {
    bool found;              // true if a solution was found.
    std::string path;        // Sequence of moves: U, D, L, R.
    int solution_length;     // Number of moves in the found solution.
    long long expanded;      // Number of expanded states.
    double elapsed_ms;       // Running time in milliseconds.

    SearchResult() {
        found = false;
        path = "";
        solution_length = -1;
        expanded = 0;
        elapsed_ms = 0.0;
    }
};

// Successor is one possible next step.
// It stores the new state and the letter of the move that was made.
struct Successor {
    State state;
    char move;
};

#endif
