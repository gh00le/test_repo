#ifndef EXPRESSION_INTERFACE_H
#define EXPRESSION_INTERFACE_H

#include "expression_ai.h"

// Prints input digits in a compact form.
std::string digits_to_string(const std::vector<int>& digits);

// Prints the result of one expression search algorithm.
void print_expression_result(const std::string& algorithm,
                             const ExpressionSearchResult& result,
                             int dls_limit = -1);

#endif
