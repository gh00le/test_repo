#ifndef AI_H
#define AI_H

#include "common.h"

// Breadth-First Search.
SearchResult BFS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col);

// Depth-Limited Search.
SearchResult DLS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col,
                       int limit);

// Heuristic A* search.
// heuristic_id = 1 -> heuristic H1.
// heuristic_id = 2 -> heuristic H2.
SearchResult ASTAR_solve(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col,
                         int heuristic_id);

// H1: number of unpainted cells that are still left.
int heuristic1(const State& state);

// H2: remaining cells + distance to the nearest unpainted cell.
int heuristic2(const State& state);

#endif
