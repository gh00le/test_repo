#include "expression.h"

// ------------------------------------------------------------
// A small helper for the greatest common divisor.
// It is written manually so the project stays compatible with C++11.
// ------------------------------------------------------------
static long long gcd_ll(long long a, long long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;

    while (b != 0) {
        long long rest = a % b;
        a = b;
        b = rest;
    }

    return a;
}

// Keeps every fraction in a standard form.
// For example, 2/4 becomes 1/2 and 1/-2 becomes -1/2.
static Fraction normalize_fraction(long long numerator,
                                   long long denominator) {
    Fraction result;

    // Division by zero is not allowed.
    // This case is checked before calling this function.
    if (denominator == 0) {
        result.numerator = 0;
        result.denominator = 1;
        return result;
    }

    if (denominator < 0) {
        numerator = -numerator;
        denominator = -denominator;
    }

    long long divisor = gcd_ll(numerator, denominator);

    if (divisor == 0) {
        result.numerator = 0;
        result.denominator = 1;
    } else {
        result.numerator = numerator / divisor;
        result.denominator = denominator / divisor;
    }

    return result;
}

static Fraction add_fraction(const Fraction& a, const Fraction& b) {
    return normalize_fraction(
        a.numerator * b.denominator + b.numerator * a.denominator,
        a.denominator * b.denominator);
}

static Fraction subtract_fraction(const Fraction& a, const Fraction& b) {
    return normalize_fraction(
        a.numerator * b.denominator - b.numerator * a.denominator,
        a.denominator * b.denominator);
}

static Fraction multiply_fraction(const Fraction& a, const Fraction& b) {
    return normalize_fraction(a.numerator * b.numerator,
                              a.denominator * b.denominator);
}

static Fraction divide_fraction(const Fraction& a, const Fraction& b) {
    return normalize_fraction(a.numerator * b.denominator,
                              a.denominator * b.numerator);
}

long double fraction_to_long_double(const Fraction& value) {
    return (long double)value.numerator / (long double)value.denominator;
}

ExpressionState make_expression_initial_state(const std::vector<int>& digits) {
    ExpressionState state;

    for (int i = 0; i < (int)digits.size(); i++) {
        ExprPart part;
        part.value = normalize_fraction(digits[i], 1);
        part.text = std::to_string(digits[i]);
        part.plain_number = true;
        state.push_back(part);
    }

    return state;
}

bool expression_is_goal(const ExpressionState& state, long long target) {
    if (state.size() != 1) {
        return false;
    }

    // We compare fractions exactly:
    // numerator / denominator == target
    return state[0].value.numerator ==
           target * state[0].value.denominator;
}

// Makes a new state where positions index and index+1
// are replaced with one combined part.
static ExpressionState replace_two_parts(const ExpressionState& state,
                                         int index,
                                         const ExprPart& combined) {
    ExpressionState next;

    for (int i = 0; i < (int)state.size(); i++) {
        if (i == index) {
            next.push_back(combined);
            i++; // Skip the second part because both were combined.
        } else {
            next.push_back(state[i]);
        }
    }

    return next;
}

std::vector<ExpressionState> expression_get_successors(
    const ExpressionState& state) {

    std::vector<ExpressionState> result;

    // We are allowed to combine only neighboring parts.
    // Because of this rule, the original order of digits never changes.
    for (int i = 0; i + 1 < (int)state.size(); i++) {
        const ExprPart& left = state[i];
        const ExprPart& right = state[i + 1];

        // --------------------------------------------------------
        // Digit concatenation.
        // It is allowed only if both parts still contain only
        // original digits and no arithmetic operation.
        // Example: "1" and "1" become "11".
        // --------------------------------------------------------
        if (left.plain_number && right.plain_number) {
            ExprPart joined;
            joined.text = left.text + right.text;
            joined.plain_number = true;

            // N <= 6, so the joined number easily fits in long long.
            long long number = 0;
            for (int p = 0; p < (int)joined.text.size(); p++) {
                number = number * 10 + (joined.text[p] - '0');
            }

            joined.value = normalize_fraction(number, 1);
            result.push_back(replace_two_parts(state, i, joined));
        }

        // Addition.
        ExprPart plus_part;
        plus_part.value = add_fraction(left.value, right.value);
        plus_part.text = "(" + left.text + "+" + right.text + ")";
        plus_part.plain_number = false;
        result.push_back(replace_two_parts(state, i, plus_part));

        // Subtraction.
        ExprPart minus_part;
        minus_part.value = subtract_fraction(left.value, right.value);
        minus_part.text = "(" + left.text + "-" + right.text + ")";
        minus_part.plain_number = false;
        result.push_back(replace_two_parts(state, i, minus_part));

        // Multiplication.
        ExprPart multiply_part;
        multiply_part.value = multiply_fraction(left.value, right.value);
        multiply_part.text = "(" + left.text + "*" + right.text + ")";
        multiply_part.plain_number = false;
        result.push_back(replace_two_parts(state, i, multiply_part));

        // Division is possible only if the right value is not zero.
        if (right.value.numerator != 0) {
            ExprPart divide_part;
            divide_part.value = divide_fraction(left.value, right.value);
            divide_part.text = "(" + left.text + "/" + right.text + ")";
            divide_part.plain_number = false;
            result.push_back(replace_two_parts(state, i, divide_part));
        }
    }

    return result;
}

std::string expression_state_key(const ExpressionState& state) {
    std::ostringstream out;

    // For an arithmetic part, only the exact value is important
    // for all future arithmetic operations.
    // For a plain number we also keep its text because the number
    // of digits matters for later concatenation.
    for (int i = 0; i < (int)state.size(); i++) {
        if (state[i].plain_number) {
            out << "P:" << state[i].text;
        } else {
            out << "E:" << state[i].value.numerator
                << '/' << state[i].value.denominator;
        }
        out << '|';
    }

    return out.str();
}
