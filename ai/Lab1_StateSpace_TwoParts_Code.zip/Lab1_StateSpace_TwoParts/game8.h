#ifndef GAME8_H
#define GAME8_H

#include "common.h"

// Creates the initial state.
// The cell under the player is immediately painted (set to 1).
State make_initial_state(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col);

// Checks whether the goal is reached.
// There must be no passable cell with value 0 left on the field.
bool is_goal(const State& state);

// Creates all states that can be reached in one move.
std::vector<Successor> get_successors(const State& state);

// Converts a state into one string.
// The string is used as a key to recognize already visited states.
std::string state_key(const State& state);

// Counts how many unpainted cells (0) are still left.
int count_unpainted(const State& state);

// Checks whether the starting coordinates are valid.
bool is_valid_start(const std::vector<std::vector<int> >& field,
                    int row,
                    int col);

#endif
