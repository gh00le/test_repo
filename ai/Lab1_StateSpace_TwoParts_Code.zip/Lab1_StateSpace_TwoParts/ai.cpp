#include "ai.h"
#include "game8.h"

// ------------------------------------------------------------
// A small structure for one search node.
// It stores the state itself, its depth and the path to it.
// ------------------------------------------------------------
struct SearchNode {
    State state;
    int depth;
    std::string path;

    SearchNode(const State& s, int d, const std::string& p) {
        state = s;
        depth = d;
        path = p;
    }
};

// ------------------------------------------------------------
// BFS - Breadth-First Search.
// ------------------------------------------------------------
SearchResult BFS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col) {
    SearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    State initial = make_initial_state(field, start_row, start_col);

    // queue is a normal first-in, first-out queue.
    // The element that was added earlier is processed earlier.
    // Because of this, BFS checks depth 0 first,
    // then all states at depth 1, then depth 2, and so on.
    std::queue<SearchNode> open;

    // visited stores states that we have already seen.
    // This prevents us from doing the same work many times.
    std::unordered_set<std::string> visited;

    open.push(SearchNode(initial, 0, ""));
    visited.insert(state_key(initial));

    while (!open.empty()) {
        SearchNode current = open.front();
        open.pop();

        // Expanding a state means taking it from the queue
        // and checking all possible next moves.
        result.expanded++;

        if (is_goal(current.state)) {
            result.found = true;
            result.path = current.path;
            result.solution_length = current.depth;
            break;
        }

        std::vector<Successor> next_states = get_successors(current.state);

        for (int i = 0; i < (int)next_states.size(); i++) {
            std::string key = state_key(next_states[i].state);

            // insert returns second == true if this key was not stored before.
            if (visited.insert(key).second) {
                std::string new_path = current.path + next_states[i].move;

                open.push(SearchNode(next_states[i].state,
                                     current.depth + 1,
                                     new_path));
            }
        }
    }

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}

// ------------------------------------------------------------
// Recursive part of DLS.
// Recursive means that this function can call itself.
// ------------------------------------------------------------
static bool dls_recursive(const State& state,
                          int depth,
                          int limit,
                          std::string path,
                          std::unordered_map<std::string, int>& best_depth,
                          SearchResult& result) {
    result.expanded++;

    if (is_goal(state)) {
        result.found = true;
        result.path = path;
        result.solution_length = depth;
        return true;
    }

    // If the depth limit is reached, this branch cannot go deeper.
    if (depth >= limit) {
        return false;
    }

    std::vector<Successor> next_states = get_successors(state);

    for (int i = 0; i < (int)next_states.size(); i++) {
        std::string key = state_key(next_states[i].state);
        int next_depth = depth + 1;

        std::unordered_map<std::string, int>::iterator it = best_depth.find(key);

        // We enter this state if:
        // 1) we have never seen it before, or
        // 2) we reached it earlier by a longer path.
        if (it == best_depth.end() || next_depth < it->second) {
            best_depth[key] = next_depth;

            if (dls_recursive(next_states[i].state,
                              next_depth,
                              limit,
                              path + next_states[i].move,
                              best_depth,
                              result)) {
                return true;
            }
        }
    }

    return false;
}

SearchResult DLS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col,
                       int limit) {
    SearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    State initial = make_initial_state(field, start_row, start_col);

    // best_depth stores the smallest depth at which
    // each state has already been reached.
    std::unordered_map<std::string, int> best_depth;
    best_depth[state_key(initial)] = 0;

    dls_recursive(initial, 0, limit, "", best_depth, result);

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}

// ------------------------------------------------------------
// Heuristic H1.
// ------------------------------------------------------------
int heuristic1(const State& state) {
    // The simplest idea is to count how many cells are still unpainted.
    // A state with 2 unpainted cells is usually closer to the goal
    // than a state with 7 unpainted cells.
    return count_unpainted(state);
}

// ------------------------------------------------------------
// Heuristic H2.
// ------------------------------------------------------------
int heuristic2(const State& state) {
    int remaining = count_unpainted(state);

    if (remaining == 0) {
        return 0;
    }

    int best_distance = std::numeric_limits<int>::max();

    // Find the unpainted cell that is closest to the player.
    for (int i = 0; i < (int)state.field.size(); i++) {
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            if (state.field[i][j] == 0) {
                // Manhattan distance is the number of row and column steps
                // if obstacles are temporarily ignored.
                int distance = std::abs(state.row - i) + std::abs(state.col - j);

                if (distance < best_distance) {
                    best_distance = distance;
                }
            }
        }
    }

    // Why do we use remaining - 1 + best_distance?
    // We need at least best_distance steps to reach the first new cell.
    // After that, there are remaining - 1 new cells left,
    // and each of them needs at least one move.
    //
    // Obstacles are intentionally ignored here.
    // Because of this, the estimate can be smaller than the real distance,
    // but it should not be larger. This is useful for A*.
    return (remaining - 1) + best_distance;
}

// ------------------------------------------------------------
// A* needs a node with a priority value.
// f = g + h
// g = number of moves already made;
// h = estimated number of moves still needed.
// ------------------------------------------------------------
struct AStarNode {
    State state;
    int depth;
    int priority;
    std::string path;

    AStarNode(const State& s, int d, int p, const std::string& way) {
        state = s;
        depth = d;
        priority = p;
        path = way;
    }
};

// priority_queue normally gives us the largest element first.
// We need the node with the smallest f value,
// so the comparison is written in the opposite direction.
struct AStarCompare {
    bool operator()(const AStarNode& a, const AStarNode& b) const {
        if (a.priority != b.priority) {
            return a.priority > b.priority;
        }

        return a.depth > b.depth;
    }
};

SearchResult ASTAR_solve(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col,
                         int heuristic_id) {
    SearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    State initial = make_initial_state(field, start_row, start_col);

    std::priority_queue<AStarNode,
                        std::vector<AStarNode>,
                        AStarCompare> open;

    // best_g stores the shortest known path length to each state.
    std::unordered_map<std::string, int> best_g;

    int h = 0;
    if (heuristic_id == 1) {
        h = heuristic1(initial);
    } else {
        h = heuristic2(initial);
    }

    open.push(AStarNode(initial, 0, h, ""));
    best_g[state_key(initial)] = 0;

    while (!open.empty()) {
        AStarNode current = open.top();
        open.pop();

        std::string current_key = state_key(current.state);

        // The priority queue may still contain an older, longer path
        // to the same state. We simply skip such an entry.
        if (best_g[current_key] != current.depth) {
            continue;
        }

        result.expanded++;

        if (is_goal(current.state)) {
            result.found = true;
            result.path = current.path;
            result.solution_length = current.depth;
            break;
        }

        std::vector<Successor> next_states = get_successors(current.state);

        for (int i = 0; i < (int)next_states.size(); i++) {
            int new_g = current.depth + 1;
            std::string key = state_key(next_states[i].state);

            std::unordered_map<std::string, int>::iterator it = best_g.find(key);

            if (it == best_g.end() || new_g < it->second) {
                best_g[key] = new_g;

                int new_h;
                if (heuristic_id == 1) {
                    new_h = heuristic1(next_states[i].state);
                } else {
                    new_h = heuristic2(next_states[i].state);
                }

                int f = new_g + new_h;

                open.push(AStarNode(next_states[i].state,
                                    new_g,
                                    f,
                                    current.path + next_states[i].move));
            }
        }
    }

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}
