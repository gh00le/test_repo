#include "interface.h"

void print_field(const std::vector<std::vector<int> >& field,
                 int player_row,
                 int player_col) {
    std::cout << "\nField:\n";
    std::cout << "P = player, # = obstacle, 0 = unpainted, 1 = painted\n\n";

    for (int i = 0; i < (int)field.size(); i++) {
        for (int j = 0; j < (int)field[i].size(); j++) {
            if (i == player_row && j == player_col) {
                std::cout << " P ";
            } else if (field[i][j] == -1) {
                std::cout << " # ";
            } else {
                std::cout << ' ' << field[i][j] << ' ';
            }
        }
        std::cout << '\n';
    }

    std::cout << '\n';
}

void print_result(const std::string& algorithm,
                  const SearchResult& result,
                  int dls_limit) {
    std::cout << "---------------------------------------------\n";
    std::cout << "Algorithm: " << algorithm << '\n';

    if (dls_limit >= 0) {
        std::cout << "Depth limit: " << dls_limit << '\n';
    }

    std::cout << "Solution found: " << (result.found ? "yes" : "no") << '\n';
    std::cout << "Expanded states: " << result.expanded << '\n';
    std::cout << "Time: " << std::fixed << std::setprecision(4)
              << result.elapsed_ms << " ms\n";

    if (result.found) {
        std::cout << "Solution length: " << result.solution_length << '\n';
        std::cout << "Path: " << result.path << '\n';
        std::cout << "Moves: U=up, R=right, D=down, L=left\n";
    }
}
