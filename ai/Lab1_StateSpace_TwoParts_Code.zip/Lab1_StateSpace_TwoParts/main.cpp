#include "common.h"
#include "game8.h"
#include "ai.h"
#include "interface.h"
#include "expression.h"
#include "expression_ai.h"
#include "expression_interface.h"

// ============================================================
// PART 1. GRID PAINTING TASK
// ============================================================

struct GridTestCase {
    std::string name;
    std::vector<std::vector<int> > field;
    int start_row;
    int start_col;
    int dls_limit;
};

void run_one_grid_test(const GridTestCase& test) {
    std::cout << "\n=================================================\n";
    std::cout << test.name << '\n';
    std::cout << "Player start: (" << test.start_row
              << ", " << test.start_col << ")\n";

    print_field(test.field, test.start_row, test.start_col);

    SearchResult bfs = BFS_solve(test.field,
                                 test.start_row,
                                 test.start_col);

    SearchResult dls = DLS_solve(test.field,
                                 test.start_row,
                                 test.start_col,
                                 test.dls_limit);

    SearchResult h1 = ASTAR_solve(test.field,
                                  test.start_row,
                                  test.start_col,
                                  1);

    SearchResult h2 = ASTAR_solve(test.field,
                                  test.start_row,
                                  test.start_col,
                                  2);

    print_result("BFS", bfs);
    print_result("DLS", dls, test.dls_limit);
    print_result("A* with heuristic H1", h1);
    print_result("A* with heuristic H2", h2);
}

int count_passable_cells(const std::vector<std::vector<int> >& field) {
    int count = 0;

    for (int i = 0; i < (int)field.size(); i++) {
        for (int j = 0; j < (int)field[i].size(); j++) {
            if (field[i][j] != -1) {
                count++;
            }
        }
    }

    return count;
}

int calculate_grid_dls_limit(const std::vector<std::vector<int> >& field) {
    int passable_cells = count_passable_cells(field);

    if (passable_cells <= 1) {
        return 0;
    }

    return 2 * (passable_cells - 1);
}

void run_custom_grid_test() {
    int rows;
    int cols;

    std::cout << "Enter number of rows: ";
    std::cin >> rows;

    std::cout << "Enter number of columns: ";
    std::cin >> cols;

    if (rows <= 0 || cols <= 0) {
        std::cout << "Field size must be positive.\n";
        return;
    }

    std::vector<std::vector<int> > field(rows,
                                         std::vector<int>(cols, 0));

    int obstacle_count;
    int max_obstacles = rows * cols - 1;

    while (true) {
        std::cout << "Enter number of obstacles (0-"
                  << max_obstacles << "): ";
        std::cin >> obstacle_count;

        if (obstacle_count >= 0 && obstacle_count <= max_obstacles) {
            break;
        }

        std::cout << "Incorrect number of obstacles. Try again.\n";
    }

    for (int number = 1; number <= obstacle_count; number++) {
        while (true) {
            int obstacle_row;
            int obstacle_col;

            std::cout << "\nObstacle " << number << " row: ";
            std::cin >> obstacle_row;

            std::cout << "Obstacle " << number << " column: ";
            std::cin >> obstacle_col;

            if (obstacle_row < 0 || obstacle_row >= rows ||
                obstacle_col < 0 || obstacle_col >= cols) {
                std::cout << "Incorrect coordinates. Try again.\n";
                continue;
            }

            if (field[obstacle_row][obstacle_col] == -1) {
                std::cout << "This cell is already an obstacle. Try again.\n";
                continue;
            }

            field[obstacle_row][obstacle_col] = -1;
            break;
        }
    }

    int start_row;
    int start_col;

    while (true) {
        std::cout << "\nEnter player row (starting from 0): ";
        std::cin >> start_row;

        std::cout << "Enter player column (starting from 0): ";
        std::cin >> start_col;

        if (start_row < 0 || start_row >= rows ||
            start_col < 0 || start_col >= cols) {
            std::cout << "Incorrect coordinates. Try again.\n";
            continue;
        }

        if (field[start_row][start_col] == -1) {
            std::cout << "The player cannot start on an obstacle. Try again.\n";
            continue;
        }

        break;
    }

    int limit = calculate_grid_dls_limit(field);

    std::cout << "\nDLS depth limit was selected automatically: "
              << limit << "\n";

    if (count_passable_cells(field) > 20) {
        std::cout << "Warning: a large field can make BFS very slow.\n";
    }

    GridTestCase custom;
    custom.name = "Custom grid test";
    custom.field = field;
    custom.start_row = start_row;
    custom.start_col = start_col;
    custom.dls_limit = limit;

    run_one_grid_test(custom);
}

std::vector<GridTestCase> create_grid_tests() {
    std::vector<GridTestCase> tests;

    GridTestCase t1;
    t1.name = "Test 1: 2 x 3 field without obstacles";
    t1.field = {{0, 0, 0}, {0, 0, 0}};
    t1.start_row = 0;
    t1.start_col = 0;
    t1.dls_limit = 8;
    tests.push_back(t1);

    GridTestCase t2;
    t2.name = "Test 2: 3 x 3 field with an obstacle in the center";
    t2.field = {{0, 0, 0}, {0, -1, 0}, {0, 0, 0}};
    t2.start_row = 0;
    t2.start_col = 0;
    t2.dls_limit = 10;
    tests.push_back(t2);

    GridTestCase t3;
    t3.name = "Test 3: 3 x 4 field with two obstacles";
    t3.field = {{0, 0, 0, 0}, {0, -1, -1, 0}, {0, 0, 0, 0}};
    t3.start_row = 1;
    t3.start_col = 0;
    t3.dls_limit = 14;
    tests.push_back(t3);

    GridTestCase t4;
    t4.name = "Test 4: 4 x 4 field with three obstacles";
    t4.field = {{0, 0, 0, -1}, {-1, 0, 0, 0}, {0, 0, -1, 0}, {0, 0, 0, 0}};
    t4.start_row = 0;
    t4.start_col = 0;
    t4.dls_limit = 18;
    tests.push_back(t4);

    GridTestCase t5;
    t5.name = "Test 5: 4 x 4 field with four obstacles";
    t5.field = {{0, 0, -1, 0}, {0, 0, -1, 0}, {0, 0, 0, 0}, {-1, 0, -1, 0}};
    t5.start_row = 0;
    t5.start_col = 0;
    t5.dls_limit = 18;
    tests.push_back(t5);

    return tests;
}

void grid_menu() {
    std::vector<GridTestCase> tests = create_grid_tests();

    while (true) {
        std::cout << "\nPART 1 - GRID PAINTING TASK\n";
        std::cout << "1 - run 5 prepared tests\n";
        std::cout << "2 - enter a custom field\n";
        std::cout << "0 - back to main menu\n";
        std::cout << "> ";

        int choice;
        std::cin >> choice;

        if (choice == 0) {
            return;
        }

        if (choice == 1) {
            for (int i = 0; i < (int)tests.size(); i++) {
                run_one_grid_test(tests[i]);
            }
        } else if (choice == 2) {
            run_custom_grid_test();
        } else {
            std::cout << "Unknown menu option.\n";
        }
    }
}

// ============================================================
// PART 2. EXPRESSION TASK (VARIANT 7)
// ============================================================

struct ExpressionTestCase {
    std::string name;
    std::vector<int> digits;
    long long target;
};

void run_one_expression_test(const ExpressionTestCase& test) {
    int dls_limit = (int)test.digits.size() - 1;

    std::cout << "\n=================================================\n";
    std::cout << test.name << '\n';
    std::cout << "Digits: " << digits_to_string(test.digits) << '\n';
    std::cout << "Target k: " << test.target << '\n';
    std::cout << "DLS depth limit: " << dls_limit << '\n';

    ExpressionSearchResult bfs =
        expression_BFS_solve(test.digits, test.target);

    ExpressionSearchResult dls =
        expression_DLS_solve(test.digits, test.target, dls_limit);

    ExpressionSearchResult h1 =
        expression_BEST_solve(test.digits, test.target, 1);

    ExpressionSearchResult h2 =
        expression_BEST_solve(test.digits, test.target, 2);

    print_expression_result("BFS", bfs);
    print_expression_result("DLS", dls, dls_limit);
    print_expression_result("BEST with heuristic H1", h1);
    print_expression_result("BEST with heuristic H2", h2);
}

std::vector<ExpressionTestCase> create_expression_tests() {
    std::vector<ExpressionTestCase> tests;

    ExpressionTestCase t1;
    t1.name = "Test 1: example from the task";
    t1.digits = {3, 2, 1, 1, 5};
    t1.target = 36;
    tests.push_back(t1);

    ExpressionTestCase t2;
    t2.name = "Test 2: multiplication and simple grouping";
    t2.digits = {1, 2, 3, 4};
    t2.target = 24;
    tests.push_back(t2);

    ExpressionTestCase t3;
    t3.name = "Test 3: short multiplication case";
    t3.digits = {2, 5, 5};
    t3.target = 50;
    tests.push_back(t3);

    ExpressionTestCase t4;
    t4.name = "Test 4: digit concatenation inside the expression";
    t4.digits = {9, 1, 2, 3};
    t4.target = 18;
    tests.push_back(t4);

    ExpressionTestCase t5;
    t5.name = "Test 5: multi-digit concatenation and division";
    t5.digits = {1, 0, 2, 4, 2};
    t5.target = 512;
    tests.push_back(t5);

    return tests;
}

void run_custom_expression_test() {
    int n;

    while (true) {
        std::cout << "Enter number of digits (1-6): ";
        std::cin >> n;

        if (n >= 1 && n <= 6) {
            break;
        }

        std::cout << "N must be from 1 to 6. Try again.\n";
    }

    std::vector<int> digits(n);

    std::cout << "Enter " << n << " digits separated by spaces:\n";

    for (int i = 0; i < n; i++) {
        while (true) {
            std::cin >> digits[i];

            if (digits[i] >= 0 && digits[i] <= 9) {
                break;
            }

            std::cout << "Each value must be one digit from 0 to 9.\n";
            std::cout << "Enter digit " << (i + 1) << " again: ";
        }
    }

    long long target;
    std::cout << "Enter target k: ";
    std::cin >> target;

    ExpressionTestCase custom;
    custom.name = "Custom expression test";
    custom.digits = digits;
    custom.target = target;

    run_one_expression_test(custom);
}

void expression_menu() {
    std::vector<ExpressionTestCase> tests = create_expression_tests();

    while (true) {
        std::cout << "\nPART 2 - EXPRESSION TASK, VARIANT 7\n";
        std::cout << "1 - run 5 prepared tests\n";
        std::cout << "2 - enter custom digits and target\n";
        std::cout << "0 - back to main menu\n";
        std::cout << "> ";

        int choice;
        std::cin >> choice;

        if (choice == 0) {
            return;
        }

        if (choice == 1) {
            for (int i = 0; i < (int)tests.size(); i++) {
                run_one_expression_test(tests[i]);
            }
        } else if (choice == 2) {
            run_custom_expression_test();
        } else {
            std::cout << "Unknown menu option.\n";
        }
    }
}

int main() {
    std::cout << "Laboratory Work No. 1\n";
    std::cout << "State-Space Search Algorithms\n";

    while (true) {
        std::cout << "\nChoose task:\n";
        std::cout << "1 - Part 1: grid painting problem\n";
        std::cout << "2 - Part 2: expression problem (Variant 7)\n";
        std::cout << "0 - exit\n";
        std::cout << "> ";

        int choice;
        std::cin >> choice;

        if (choice == 0) {
            break;
        }

        if (choice == 1) {
            grid_menu();
        } else if (choice == 2) {
            expression_menu();
        } else {
            std::cout << "Unknown menu option.\n";
        }
    }

    return 0;
}
