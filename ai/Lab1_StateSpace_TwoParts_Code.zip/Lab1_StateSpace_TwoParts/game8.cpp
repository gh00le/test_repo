#include "game8.h"

// ------------------------------------------------------------
// Cell values used in this task:
//   0  - passable, but not painted yet;
//   1  - passable and already painted;
//  -1  - obstacle. The player cannot move there.
//
// The player can move only up, right, down and left.
// When the player moves onto a 0 cell, it becomes 1.
// If the player moves onto a 1 cell again, it stays 1.
// A painted cell is never changed back to 0.
// ------------------------------------------------------------

bool is_valid_start(const std::vector<std::vector<int> >& field,
                    int row,
                    int col) {
    if (field.empty()) {
        return false;
    }

    if (row < 0 || row >= (int)field.size()) {
        return false;
    }

    if (col < 0 || col >= (int)field[0].size()) {
        return false;
    }

    // The player cannot start on an obstacle.
    if (field[row][col] == -1) {
        return false;
    }

    return true;
}

State make_initial_state(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col) {
    State state;
    state.field = field;
    state.row = start_row;
    state.col = start_col;

    // The cell under the player is already painted at the beginning.
    state.field[start_row][start_col] = 1;

    return state;
}

bool is_goal(const State& state) {
    // Check every row of the field.
    for (int i = 0; i < (int)state.field.size(); i++) {
        // Check every cell in the current row.
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            // If we find at least one 0, the task is not finished yet.
            if (state.field[i][j] == 0) {
                return false;
            }
        }
    }

    // No 0 cells are left, so the goal is reached.
    return true;
}

int count_unpainted(const State& state) {
    int count = 0;

    for (int i = 0; i < (int)state.field.size(); i++) {
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            if (state.field[i][j] == 0) {
                count++;
            }
        }
    }

    return count;
}

std::vector<Successor> get_successors(const State& state) {
    std::vector<Successor> result;

    // Coordinate changes for four possible directions:
    // U = up, R = right, D = down, L = left.
    const int dr[4] = {-1, 0, 1, 0};
    const int dc[4] = {0, 1, 0, -1};
    const char names[4] = {'U', 'R', 'D', 'L'};

    int rows = (int)state.field.size();
    int cols = (int)state.field[0].size();

    for (int i = 0; i < 4; i++) {
        int new_row = state.row + dr[i];
        int new_col = state.col + dc[i];

        // First, check that the new position is inside the field.
        if (new_row < 0 || new_row >= rows ||
            new_col < 0 || new_col >= cols) {
            continue;
        }

        // Value -1 means obstacle, so the player cannot move there.
        if (state.field[new_row][new_col] == -1) {
            continue;
        }

        // Make a copy of the current state.
        State next = state;

        // Move the player.
        next.row = new_row;
        next.col = new_col;

        // Paint the new cell.
        // If it was already 1, it simply stays 1.
        next.field[new_row][new_col] = 1;

        Successor s;
        s.state = next;
        s.move = names[i];
        result.push_back(s);
    }

    return result;
}

std::string state_key(const State& state) {
    // We need one string that uniquely describes the whole state.
    // Then we can store it in unordered_set / unordered_map
    // and quickly check whether this state was already visited.
    std::ostringstream out;

    out << state.row << ',' << state.col << '|';

    for (int i = 0; i < (int)state.field.size(); i++) {
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            if (state.field[i][j] == -1) {
                out << 'X';
            } else {
                out << state.field[i][j];
            }
        }
        out << '/';
    }

    return out.str();
}
