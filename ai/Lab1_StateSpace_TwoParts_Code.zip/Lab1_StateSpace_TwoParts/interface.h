#ifndef INTERFACE_H
#define INTERFACE_H

#include "common.h"

// Prints the field in a readable form.
void print_field(const std::vector<std::vector<int> >& field,
                 int player_row,
                 int player_col);

// Prints the result of one search algorithm.
void print_result(const std::string& algorithm,
                  const SearchResult& result,
                  int dls_limit = -1);

#endif
