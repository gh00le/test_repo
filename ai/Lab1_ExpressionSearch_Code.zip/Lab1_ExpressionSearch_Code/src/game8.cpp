#include <game8.h>

static long long gcd_abs(long long a, long long b) {
    a = std::llabs(a); b = std::llabs(b);
    return std::gcd(a, b);
}

Fraction make_fraction(long long num, long long den) {
    if (den == 0) throw std::runtime_error("division by zero");
    if (den < 0) { num = -num; den = -den; }
    long long g = gcd_abs(num, den);
    if (g == 0) return {0, 1};
    return {num / g, den / g};
}

bool fraction_equal(const Fraction& a, const Fraction& b) {
    return a.num == b.num && a.den == b.den;
}

double fraction_abs_distance(const Fraction& a, long long target) {
    long double diff = std::fabsl((long double)a.num / a.den - (long double)target);
    return (double)diff;
}

std::string fraction_to_string(const Fraction& f) {
    if (f.den == 1) return std::to_string(f.num);
    return std::to_string(f.num) + "/" + std::to_string(f.den);
}

State make_initial_state(const std::vector<int>& digits) {
    State s;
    s.reserve(digits.size());
    for (int d : digits) {
        std::string t(1, char('0' + d));
        s.push_back({make_fraction(d), t, true, t});
    }
    return s;
}

bool is_goal(const State& state, long long target) {
    return state.size() == 1 && state[0].value.den == 1 && state[0].value.num == target;
}

static Fraction add(const Fraction& a, const Fraction& b) {
    return make_fraction(a.num * b.den + b.num * a.den, a.den * b.den);
}
static Fraction sub(const Fraction& a, const Fraction& b) {
    return make_fraction(a.num * b.den - b.num * a.den, a.den * b.den);
}
static Fraction mul(const Fraction& a, const Fraction& b) {
    return make_fraction(a.num * b.num, a.den * b.den);
}
static Fraction divf(const Fraction& a, const Fraction& b) {
    if (b.num == 0) throw std::runtime_error("division by zero");
    return make_fraction(a.num * b.den, a.den * b.num);
}

static State combine_at(const State& state, std::size_t i, const Fragment& merged) {
    State next;
    next.reserve(state.size() - 1);
    for (std::size_t j = 0; j < i; ++j) next.push_back(state[j]);
    next.push_back(merged);
    for (std::size_t j = i + 2; j < state.size(); ++j) next.push_back(state[j]);
    return next;
}

std::vector<State> get_successors(const State& state) {
    std::vector<State> out;
    if (state.size() < 2) return out;
    out.reserve((state.size() - 1) * 5);

    for (std::size_t i = 0; i + 1 < state.size(); ++i) {
        const Fragment& a = state[i];
        const Fragment& b = state[i + 1];

        out.push_back(combine_at(state, i, {add(a.value,b.value), "("+a.expr+"+"+b.expr+")", false, ""}));
        out.push_back(combine_at(state, i, {sub(a.value,b.value), "("+a.expr+"-"+b.expr+")", false, ""}));
        out.push_back(combine_at(state, i, {mul(a.value,b.value), "("+a.expr+"*"+b.expr+")", false, ""}));
        if (b.value.num != 0)
            out.push_back(combine_at(state, i, {divf(a.value,b.value), "("+a.expr+"/"+b.expr+")", false, ""}));

        if (a.pure_number && b.pure_number) {
            std::string d = a.digits + b.digits;
            long long v = std::stoll(d);
            out.push_back(combine_at(state, i, {make_fraction(v), d, true, d}));
        }
    }
    return out;
}

std::string state_key(const State& state) {
    std::ostringstream ss;
    for (const auto& f : state) {
        ss << f.value.num << '/' << f.value.den << ':';
        if (f.pure_number) ss << 'P' << f.digits;
        else ss << 'E';
        ss << '|';
    }
    return ss.str();
}
