#include <ai.h>
#include <interface.h>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <vector>

struct Case{std::vector<int>d; long long k;};

template <class F>
SearchResult median_run(F fn, int repeats=101) {
    std::vector<SearchResult> rs;
    rs.reserve(repeats);
    for(int i=0;i<repeats;++i) rs.push_back(fn());
    std::sort(rs.begin(), rs.end(), [](const SearchResult&a,const SearchResult&b){return a.elapsed_ms<b.elapsed_ms;});
    SearchResult m=rs[repeats/2];
    // Results are deterministic except timing; use first run's semantic fields/count as a consistency anchor.
    m.found=rs[0].found; m.expression=rs[0].expression; m.solution_length=rs[0].solution_length; m.expanded=rs[0].expanded;
    return m;
}

void row(int n,const Case&c,const std::string&a,int lim,const SearchResult&r){
    std::cout<<n<<'\t'<<digits_to_string(c.d)<<'\t'<<c.k<<'\t'<<a<<'\t';
    if(lim<0) std::cout<<'-'; else std::cout<<lim;
    std::cout<<'\t'<<(r.found?"yes":"no")<<'\t'<<r.expanded<<'\t'<<std::fixed<<std::setprecision(6)<<r.elapsed_ms<<'\t'<<r.solution_length<<'\t'<<r.expression<<'\n';
}
int main(){
 std::vector<Case> cs={{{3,2,1,1,5},36},{{1,2,5,2,5},100},{{1,0,2,4,2},512},{{8,2,3,1,1},12},{{9,1,2,3,4},15}};
 std::cout<<"case\tdigits\ttarget\talgorithm\tlimit\tfound\texpanded\tmedian_ms\tlength\texpression\n";
 int n=0; for(auto &c:cs){++n; int lim=(int)c.d.size()-1;
  row(n,c,"BFS",-1,median_run([&](){return BFS_solve(c.d,c.k);}));
  row(n,c,"DLS",lim,median_run([&](){return DLS_solve(c.d,c.k,lim);}));
  row(n,c,"BEST-H1",-1,median_run([&](){return BEST_solve(c.d,c.k,1);}));
  row(n,c,"BEST-H2",-1,median_run([&](){return BEST_solve(c.d,c.k,2);}));
 }
}
