#include <interface.h>

std::vector<int> parse_digits(const std::string& input) {
    std::stringstream ss(input);
    std::vector<int> digits;
    int d;
    while (ss >> d) {
        if (d < 0 || d > 9) throw std::runtime_error("Each item must be a digit from 0 to 9");
        digits.push_back(d);
    }
    if (digits.empty() || digits.size() > 6) throw std::runtime_error("N must be from 1 to 6");
    return digits;
}

std::string digits_to_string(const std::vector<int>& digits) {
    std::ostringstream ss;
    ss << '[';
    for (std::size_t i = 0; i < digits.size(); ++i) {
        if (i) ss << ',';
        ss << digits[i];
    }
    ss << ']';
    return ss.str();
}
