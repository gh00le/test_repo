#include <ai.h>
#include <game8.h>

struct Node {
    State state;
    int depth = 0;
};

SearchResult BFS_solve(const std::vector<int>& digits, long long target) {
    auto t0 = std::chrono::steady_clock::now();
    SearchResult r;
    State init = make_initial_state(digits);
    std::queue<Node> open;
    std::unordered_set<std::string> seen;
    open.push({init,0});
    seen.insert(state_key(init));

    while (!open.empty()) {
        Node cur = std::move(open.front()); open.pop();
        ++r.expanded;
        if (is_goal(cur.state, target)) {
            r.found = true;
            r.expression = cur.state[0].expr;
            r.solution_length = cur.depth;
            break;
        }
        for (State& next : get_successors(cur.state)) {
            std::string key = state_key(next);
            if (seen.insert(key).second) open.push({std::move(next), cur.depth + 1});
        }
    }
    r.elapsed_ms = std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();
    return r;
}

static bool dls_rec(const State& state, long long target, int depth, int limit,
                    std::unordered_set<std::string>& seen, SearchResult& r,
                    std::string& solution_expr, int& solution_depth) {
    ++r.expanded;
    if (is_goal(state, target)) {
        solution_expr = state[0].expr;
        solution_depth = depth;
        return true;
    }
    if (depth >= limit) return false;

    for (State& next : get_successors(state)) {
        std::string key = state_key(next);
        if (!seen.insert(key).second) continue;
        if (dls_rec(next, target, depth+1, limit, seen, r, solution_expr, solution_depth)) return true;
    }
    return false;
}

SearchResult DLS_solve(const std::vector<int>& digits, long long target, int limit) {
    auto t0 = std::chrono::steady_clock::now();
    SearchResult r;
    State init = make_initial_state(digits);
    std::unordered_set<std::string> seen;
    seen.insert(state_key(init));
    std::string expr;
    int depth = -1;
    if (dls_rec(init, target, 0, limit, seen, r, expr, depth)) {
        r.found = true;
        r.expression = expr;
        r.solution_length = depth;
    }
    r.elapsed_ms = std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();
    return r;
}

double heuristic_distance(const State& state, long long target) {
    double best = std::numeric_limits<double>::infinity();
    for (const auto& f : state) best = std::min(best, fraction_abs_distance(f.value, target));
    return best;
}

double heuristic_one_step(const State& state, long long target) {
    if (state.size() <= 1) return heuristic_distance(state, target);
    double best = std::numeric_limits<double>::infinity();
    for (const auto& next : get_successors(state)) {
        for (const auto& f : next) best = std::min(best, fraction_abs_distance(f.value, target));
    }
    return best;
}

SearchResult BEST_solve(const std::vector<int>& digits, long long target, int heuristic_id) {
    auto t0 = std::chrono::steady_clock::now();
    SearchResult r;
    State init = make_initial_state(digits);
    using Item = std::tuple<double,int,std::size_t,State>; // h, remaining, tie, state
    struct Cmp {
        bool operator()(const Item& a, const Item& b) const {
            if (std::get<0>(a) != std::get<0>(b)) return std::get<0>(a) > std::get<0>(b);
            if (std::get<1>(a) != std::get<1>(b)) return std::get<1>(a) > std::get<1>(b);
            return std::get<2>(a) > std::get<2>(b);
        }
    };
    std::priority_queue<Item,std::vector<Item>,Cmp> open;
    std::unordered_set<std::string> seen;
    std::size_t tie = 0;
    auto H = [=](const State& s) { return heuristic_id == 1 ? heuristic_distance(s,target) : heuristic_one_step(s,target); };
    open.push({H(init), (int)init.size()-1, tie++, init});
    seen.insert(state_key(init));

    int initial_n = (int)init.size();
    while (!open.empty()) {
        auto item = open.top(); open.pop();
        State cur = std::move(std::get<3>(item));
        int depth = initial_n - (int)cur.size();
        ++r.expanded;
        if (is_goal(cur,target)) {
            r.found = true;
            r.expression = cur[0].expr;
            r.solution_length = depth;
            break;
        }
        for (State& next : get_successors(cur)) {
            std::string key = state_key(next);
            if (seen.insert(key).second)
                open.push({H(next), (int)next.size()-1, tie++, std::move(next)});
        }
    }
    r.elapsed_ms = std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();
    return r;
}
