#include <ai.h>
#include <interface.h>

#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
#include <vector>

struct Case {
    std::vector<int> digits;
    long long target;
};

static void print_result(const std::string& algorithm,
                         int limit,
                         const SearchResult& r) {
    std::cout << "\nAlgorithm: " << algorithm << '\n';
    if (limit >= 0) {
        std::cout << "Depth limit: " << limit << '\n';
    }
    std::cout << "Solution found: " << (r.found ? "yes" : "no") << '\n';
    std::cout << "Expanded states: " << r.expanded << '\n';
    std::cout << "Execution time: " << std::fixed << std::setprecision(6)
              << r.elapsed_ms << " ms\n";
    std::cout << "Solution length: " << r.solution_length << '\n';
    if (r.found) {
        std::cout << "Expression: " << r.expression << '\n';
    }
}

static void print_table_row(int case_no,
                            const Case& c,
                            const char* algorithm,
                            int limit,
                            const SearchResult& r) {
    std::cout << case_no << '\t'
              << digits_to_string(c.digits) << '\t'
              << c.target << '\t'
              << algorithm << '\t';

    if (limit >= 0) std::cout << limit;
    else std::cout << '-';

    std::cout << '\t'
              << (r.found ? "yes" : "no") << '\t'
              << r.expanded << '\t'
              << std::fixed << std::setprecision(6) << r.elapsed_ms << '\t'
              << r.solution_length << '\t'
              << r.expression << '\n';
}

static void run_lab_cases() {
    // The same five cases that are used in the Word report.
    const std::vector<Case> cases = {
        {{3, 2, 1, 1, 5}, 36},
        {{1, 2, 5, 2, 5}, 100},
        {{1, 0, 2, 4, 2}, 512},
        {{8, 2, 3, 1, 1}, 12},
        {{9, 1, 2, 3, 4}, 15}
    };

    std::cout << "case\tdigits\ttarget\talgorithm\tlimit\tfound\texpanded\tms\tlength\texpression\n";

    int case_no = 1;
    for (const auto& c : cases) {
        const int limit = static_cast<int>(c.digits.size()) - 1;

        print_table_row(case_no, c, "BFS", -1,
                        BFS_solve(c.digits, c.target));
        print_table_row(case_no, c, "DLS", limit,
                        DLS_solve(c.digits, c.target, limit));
        print_table_row(case_no, c, "BEST-H1", -1,
                        BEST_solve(c.digits, c.target, 1));
        print_table_row(case_no, c, "BEST-H2", -1,
                        BEST_solve(c.digits, c.target, 2));
        ++case_no;
    }
}

static std::vector<int> read_digits() {
    while (true) {
        std::cout << "Enter from 1 to 6 digits separated by spaces (example: 3 2 1 1 5):\n> ";
        std::string line;
        std::getline(std::cin, line);

        try {
            return parse_digits(line);
        } catch (const std::exception& e) {
            std::cout << "Input error: " << e.what() << "\n\n";
        }
    }
}

static long long read_target() {
    while (true) {
        std::cout << "Enter target k:\n> ";
        long long target;
        if (std::cin >> target) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return target;
        }

        std::cout << "Input error. k must be an integer.\n\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

static int read_int(const std::string& prompt) {
    while (true) {
        std::cout << prompt << "\n> ";
        int value;
        if (std::cin >> value) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
        std::cout << "Input error. Enter an integer.\n\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

static void run_custom_case() {
    const std::vector<int> digits = read_digits();
    const long long target = read_target();

    std::cout << "\nInitial state: " << digits_to_string(digits)
              << ", target k = " << target << "\n";
    std::cout << "Choose algorithm:\n"
              << "1 - BFS\n"
              << "2 - DLS\n"
              << "3 - Best-First, heuristic H1\n"
              << "4 - Best-First, heuristic H2\n"
              << "5 - Run all algorithms\n";

    const int choice = read_int("Algorithm number:");
    const int natural_limit = static_cast<int>(digits.size()) - 1;

    switch (choice) {
        case 1:
            print_result("BFS", -1, BFS_solve(digits, target));
            break;
        case 2: {
            int limit = read_int("Enter DLS depth limit (recommended N-1 = "
                                 + std::to_string(natural_limit) + "):");
            print_result("DLS", limit, DLS_solve(digits, target, limit));
            break;
        }
        case 3:
            print_result("Best-First H1", -1, BEST_solve(digits, target, 1));
            break;
        case 4:
            print_result("Best-First H2", -1, BEST_solve(digits, target, 2));
            break;
        case 5:
            print_result("BFS", -1, BFS_solve(digits, target));
            print_result("DLS", natural_limit,
                         DLS_solve(digits, target, natural_limit));
            print_result("Best-First H1", -1,
                         BEST_solve(digits, target, 1));
            print_result("Best-First H2", -1,
                         BEST_solve(digits, target, 2));
            break;
        default:
            std::cout << "Unknown algorithm number.\n";
            break;
    }
}

int main() {
    std::cout << "Laboratory work #1 - State-space search for arithmetic expressions\n";
    std::cout << "Allowed operations: +, -, *, /, parentheses and digit concatenation.\n\n";

    while (true) {
        std::cout << "Menu:\n"
                  << "1 - Run the 5 laboratory test cases\n"
                  << "2 - Test your own input\n"
                  << "0 - Exit\n";

        const int choice = read_int("Choose mode:");
        std::cout << '\n';

        if (choice == 0) break;
        if (choice == 1) run_lab_cases();
        else if (choice == 2) run_custom_case();
        else std::cout << "Unknown menu item.\n";

        std::cout << "\n----------------------------------------\n\n";
    }

    return 0;
}
