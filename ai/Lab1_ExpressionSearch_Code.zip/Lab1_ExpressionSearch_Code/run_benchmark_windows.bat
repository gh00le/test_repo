@echo off
chcp 65001 >nul

if exist "build\Release\ExpressionBenchmark.exe" (
    "build\Release\ExpressionBenchmark.exe"
) else if exist "build\ExpressionBenchmark.exe" (
    "build\ExpressionBenchmark.exe"
) else (
    echo Benchmark executable was not found.
    echo First run build_windows.bat.
)

echo.
pause
