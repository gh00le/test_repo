@echo off
chcp 65001 >nul

echo ========================================
echo  Laboratory work #1 - build and run
echo ========================================
echo.

where cmake >nul 2>nul
if errorlevel 1 (
    echo ERROR: CMake was not found in PATH.
    echo Install CMake and add it to PATH, then run this file again.
    pause
    exit /b 1
)

cmake -S . -B build
if errorlevel 1 (
    echo.
    echo CMake configuration failed.
    pause
    exit /b 1
)

cmake --build build --config Release
if errorlevel 1 (
    echo.
    echo Build failed.
    pause
    exit /b 1
)

echo.
echo Build completed successfully.
echo.

if exist "build\Release\ExpressionSearch.exe" (
    "build\Release\ExpressionSearch.exe"
) else if exist "build\ExpressionSearch.exe" (
    "build\ExpressionSearch.exe"
) else (
    echo ERROR: ExpressionSearch.exe was not found after build.
)

echo.
pause
