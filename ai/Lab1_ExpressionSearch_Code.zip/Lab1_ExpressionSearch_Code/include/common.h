#pragma once
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <functional>
#include <iostream>
#include <limits>
#include <numeric>
#include <queue>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

struct Fraction {
    long long num = 0;
    long long den = 1;
};

struct Fragment {
    Fraction value;
    std::string expr;
    bool pure_number = false;
    std::string digits;
};

using State = std::vector<Fragment>;

struct SearchResult {
    bool found = false;
    std::string expression;
    int solution_length = -1;
    std::size_t expanded = 0;
    double elapsed_ms = 0.0;
};
