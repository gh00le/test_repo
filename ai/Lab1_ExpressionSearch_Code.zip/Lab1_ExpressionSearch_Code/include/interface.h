#pragma once
#include <common.h>

std::vector<int> parse_digits(const std::string& input);
std::string digits_to_string(const std::vector<int>& digits);
