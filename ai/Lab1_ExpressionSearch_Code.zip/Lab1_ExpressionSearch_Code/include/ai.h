#pragma once
#include <common.h>

SearchResult BFS_solve(const std::vector<int>& digits, long long target);
SearchResult DLS_solve(const std::vector<int>& digits, long long target, int limit);
SearchResult BEST_solve(const std::vector<int>& digits, long long target, int heuristic_id);

double heuristic_distance(const State& state, long long target);
double heuristic_one_step(const State& state, long long target);
