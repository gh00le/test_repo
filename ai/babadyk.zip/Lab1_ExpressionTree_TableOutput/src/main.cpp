#include <ai.h>
#include <interface.h>
#include <game8.h>

struct TestCase {
    std::string digits;
    long long target;
};

struct TestResult {
    std::string digits;
    long long target;

    std::vector<State> bfs;
    std::size_t bfs_expanded;
    double bfs_time;

    std::vector<State> dls;
    std::size_t dls_expanded;
    double dls_time;
    int dls_limit;

    std::vector<State> h1;
    std::size_t h1_expanded;
    double h1_time;

    std::vector<State> h2;
    std::size_t h2_expanded;
    double h2_time;
};

static bool is_optimal_solution(const std::string& digits, const std::vector<State>& solution) {
    if (solution.empty()) return false;

    State start = parse_state(digits);
    int minimum_length = static_cast<int>(state_size(start)) - 1;
    int actual_length = static_cast<int>(solution.size()) - 1;

    return actual_length == minimum_length;
}

static std::string format_time(double time_ms) {
    std::ostringstream out;
    out << std::fixed << std::setprecision(4) << time_ms;
    return out.str();
}

static std::string solution_length_text(const std::vector<State>& solution) {
    if (solution.empty()) return "-";

    std::ostringstream out;
    out << static_cast<int>(solution.size()) - 1;
    return out.str();
}

static std::string practicality_text(const std::vector<State>& solution, std::size_t expanded) {
    if (solution.empty() || expanded == 0) return "-";

    double practicality = static_cast<double>(solution.size() - 1) / static_cast<double>(expanded);
    std::ostringstream out;
    out << std::fixed << std::setprecision(6) << practicality;
    return out.str();
}

static void print_separator() {
    std::cout << std::string(133, '-') << std::endl;
}

static void print_table_header() {
    print_separator();
    std::cout << std::left
              << "| " << std::setw(14) << "Algorithm"
              << "| " << std::setw(18) << "Initial state"
              << "| " << std::setw(10) << "Expanded"
              << "| " << std::setw(12) << "Time (ms)"
              << "| " << std::setw(8) << "Length"
              << "| " << std::setw(11) << "Depth limit"
              << "| " << std::setw(7) << "Found"
              << "| " << std::setw(8) << "Optimal"
              << "| " << std::setw(12) << "P = L / N"
              << "|" << std::endl;
    print_separator();
}

static void print_result_row(
    const std::string& algorithm,
    const std::string& digits,
    const std::vector<State>& solution,
    std::size_t expanded,
    double time_ms,
    int depth_limit,
    bool optimal
) {
    std::string depth_text = "-";
    if (depth_limit >= 0) {
        std::ostringstream out;
        out << depth_limit;
        depth_text = out.str();
    }

    std::cout << std::left
              << "| " << std::setw(14) << algorithm
              << "| " << std::setw(18) << digits
              << "| " << std::setw(10) << expanded
              << "| " << std::setw(12) << format_time(time_ms)
              << "| " << std::setw(8) << solution_length_text(solution)
              << "| " << std::setw(11) << depth_text
              << "| " << std::setw(7) << (solution.empty() ? "no" : "yes")
              << "| " << std::setw(8) << (optimal ? "yes" : "no")
              << "| " << std::setw(12) << practicality_text(solution, expanded)
              << "|" << std::endl;
}

static void print_result_table(const TestResult& result) {
    std::cout << "Target: " << result.target << std::endl;
    print_table_header();

    print_result_row(
        "BFS",
        result.digits,
        result.bfs,
        result.bfs_expanded,
        result.bfs_time,
        -1,
        is_optimal_solution(result.digits, result.bfs)
    );

    print_result_row(
        "DLS",
        result.digits,
        result.dls,
        result.dls_expanded,
        result.dls_time,
        result.dls_limit,
        is_optimal_solution(result.digits, result.dls)
    );

    print_result_row(
        "Heuristic H1",
        result.digits,
        result.h1,
        result.h1_expanded,
        result.h1_time,
        -1,
        is_optimal_solution(result.digits, result.h1)
    );

    print_result_row(
        "Heuristic H2",
        result.digits,
        result.h2,
        result.h2_expanded,
        result.h2_time,
        -1,
        is_optimal_solution(result.digits, result.h2)
    );

    print_separator();
    std::cout << std::endl;
}

static TestResult run_test(const std::string& digits, long long target) {
    set_target(target);
    State start = parse_state(digits);
    int limit = static_cast<int>(state_size(start)) - 1;

    TestResult result;
    result.digits = digits;
    result.target = target;
    result.dls_limit = limit;

    std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
    result.bfs = BFS_solve(start);
    std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
    result.bfs_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.bfs_expanded = get_last_expanded();

    begin = std::chrono::steady_clock::now();
    result.dls = DLS_solve(start, limit);
    end = std::chrono::steady_clock::now();
    result.dls_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.dls_expanded = get_last_expanded();

    begin = std::chrono::steady_clock::now();
    result.h1 = EST_solve(start, heuristic1);
    end = std::chrono::steady_clock::now();
    result.h1_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.h1_expanded = get_last_expanded();

    begin = std::chrono::steady_clock::now();
    result.h2 = EST_solve(start, heuristic2);
    end = std::chrono::steady_clock::now();
    result.h2_time = std::chrono::duration<double, std::milli>(end - begin).count();
    result.h2_expanded = get_last_expanded();

    print_result_table(result);
    return result;
}

static void save_all_results(const std::vector<TestResult>& results) {
    for (std::size_t i = 0; i < results.size(); ++i) {
        bool append = i != 0;

        save_solution_steps(
            "result_BFS.txt",
            "BFS",
            results[i].digits,
            results[i].target,
            results[i].bfs,
            results[i].bfs_expanded,
            results[i].bfs_time,
            -1,
            is_optimal_solution(results[i].digits, results[i].bfs),
            append
        );

        save_solution_steps(
            "result_DLS.txt",
            "DLS",
            results[i].digits,
            results[i].target,
            results[i].dls,
            results[i].dls_expanded,
            results[i].dls_time,
            results[i].dls_limit,
            is_optimal_solution(results[i].digits, results[i].dls),
            append
        );

        save_solution_steps(
            "result_H1.txt",
            "Heuristic H1",
            results[i].digits,
            results[i].target,
            results[i].h1,
            results[i].h1_expanded,
            results[i].h1_time,
            -1,
            is_optimal_solution(results[i].digits, results[i].h1),
            append
        );

        save_solution_steps(
            "result_H2.txt",
            "Heuristic H2",
            results[i].digits,
            results[i].target,
            results[i].h2,
            results[i].h2_expanded,
            results[i].h2_time,
            -1,
            is_optimal_solution(results[i].digits, results[i].h2),
            append
        );
    }

    std::cout << "Results saved to result_BFS.txt, result_DLS.txt, result_H1.txt and result_H2.txt" << std::endl << std::endl;
}

static void ask_to_save(const std::vector<TestResult>& results) {
    int save = 0;
    std::cout << "Save results and solution steps to files?" << std::endl;
    std::cout << "1 - yes" << std::endl;
    std::cout << "0 - no" << std::endl;
    std::cout << "> ";
    std::cin >> save;
    std::cin.ignore(10000, '\n');
    std::cout << std::endl;

    if (save == 1) save_all_results(results);
}

int main() {
    TestCase tests[5] = {
        {"3 2 1 1 5", 36},
        {"1 2 3 4", 24},
        {"2 5 5", 50},
        {"9 1 2 3", 18},
        {"1 0 2 4 2", 512}
    };

    int mode = -1;

    while (mode != 0) {
        std::cout << "1 - prepared tests" << std::endl;
        std::cout << "2 - custom test" << std::endl;
        std::cout << "0 - exit" << std::endl;
        std::cout << "> ";
        std::cin >> mode;
        std::cin.ignore(10000, '\n');
        std::cout << std::endl;

        if (mode == 1) {
            std::vector<TestResult> results;

            for (int i = 0; i < 5; ++i) {
                std::cout << "Test " << i + 1 << std::endl;
                results.push_back(run_test(tests[i].digits, tests[i].target));
            }

            ask_to_save(results);
        }
        else if (mode == 2) {
            std::string digits;
            long long target;

            std::cout << "Enter digits separated by spaces: ";
            std::getline(std::cin, digits);

            State check = parse_state(digits);
            if (state_size(check) == 0 || state_size(check) > 6) {
                std::cout << "Number of digits must be from 1 to 6." << std::endl << std::endl;
                continue;
            }

            std::cout << "Enter target: ";
            std::cin >> target;
            std::cin.ignore(10000, '\n');
            std::cout << std::endl;

            std::vector<TestResult> results;
            results.push_back(run_test(digits, target));
            ask_to_save(results);
        }
    }

    return 0;
}
