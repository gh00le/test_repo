#include "ai.h"
#include "game8.h"

// ------------------------------------------------------------
// Небольшая внутренняя структура для узла поиска.
// Она хранит само состояние, глубину и путь до него.
// ------------------------------------------------------------
struct SearchNode {
    State state;
    int depth;
    std::string path;

    SearchNode(const State& s, int d, const std::string& p) {
        state = s;
        depth = d;
        path = p;
    }
};

// ------------------------------------------------------------
// BFS - поиск в ширину.
// ------------------------------------------------------------
SearchResult BFS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col) {
    SearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    State initial = make_initial_state(field, start_row, start_col);

    // queue — обычная очередь.
    // Кто раньше добавлен, тот раньше будет обработан.
    // Поэтому BFS сначала проверяет глубину 0,
    // потом все состояния глубины 1, затем глубины 2 и так далее.
    std::queue<SearchNode> open;

    // visited хранит состояния, которые мы уже встречали.
    // Это нужно, чтобы не делать одну и ту же работу много раз.
    std::unordered_set<std::string> visited;

    open.push(SearchNode(initial, 0, ""));
    visited.insert(state_key(initial));

    while (!open.empty()) {
        SearchNode current = open.front();
        open.pop();

        // "Раскрыть вершину" означает взять состояние из очереди
        // и начать рассматривать его возможные переходы.
        result.expanded++;

        if (is_goal(current.state)) {
            result.found = true;
            result.path = current.path;
            result.solution_length = current.depth;
            break;
        }

        std::vector<Successor> next_states = get_successors(current.state);

        for (int i = 0; i < (int)next_states.size(); i++) {
            std::string key = state_key(next_states[i].state);

            // insert возвращает second == true,
            // если такого ключа раньше еще не было.
            if (visited.insert(key).second) {
                std::string new_path = current.path + next_states[i].move;

                open.push(SearchNode(next_states[i].state,
                                     current.depth + 1,
                                     new_path));
            }
        }
    }

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}

// ------------------------------------------------------------
// Рекурсивная часть DLS.
// "Рекурсивная" значит, что функция вызывает сама себя.
// ------------------------------------------------------------
static bool dls_recursive(const State& state,
                          int depth,
                          int limit,
                          std::string path,
                          std::unordered_map<std::string, int>& best_depth,
                          SearchResult& result) {
    result.expanded++;

    if (is_goal(state)) {
        result.found = true;
        result.path = path;
        result.solution_length = depth;
        return true;
    }

    // Если дошли до установленного предела глубины,
    // дальше эту ветку развивать нельзя.
    if (depth >= limit) {
        return false;
    }

    std::vector<Successor> next_states = get_successors(state);

    for (int i = 0; i < (int)next_states.size(); i++) {
        std::string key = state_key(next_states[i].state);
        int next_depth = depth + 1;

        std::unordered_map<std::string, int>::iterator it = best_depth.find(key);

        // Мы идем в это состояние, если:
        // 1) еще никогда его не встречали;
        // или
        // 2) раньше приходили туда более длинным путем.
        if (it == best_depth.end() || next_depth < it->second) {
            best_depth[key] = next_depth;

            if (dls_recursive(next_states[i].state,
                              next_depth,
                              limit,
                              path + next_states[i].move,
                              best_depth,
                              result)) {
                return true;
            }
        }
    }

    return false;
}

SearchResult DLS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col,
                       int limit) {
    SearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    State initial = make_initial_state(field, start_row, start_col);

    // best_depth запоминает, на какой минимальной глубине
    // мы уже встречали каждое состояние.
    std::unordered_map<std::string, int> best_depth;
    best_depth[state_key(initial)] = 0;

    dls_recursive(initial, 0, limit, "", best_depth, result);

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}

// ------------------------------------------------------------
// Эвристика H1.
// ------------------------------------------------------------
int heuristic1(const State& state) {
    // Самая простая идея:
    // считаем, сколько клеток еще не закрашено.
    //
    // Если осталось 2 клетки, состояние обычно ближе к цели,
    // чем состояние, где осталось 7 клеток.
    return count_unpainted(state);
}

// ------------------------------------------------------------
// Эвристика H2.
// ------------------------------------------------------------
int heuristic2(const State& state) {
    int remaining = count_unpainted(state);

    if (remaining == 0) {
        return 0;
    }

    int best_distance = std::numeric_limits<int>::max();

    // Ищем незакрашенную клетку, которая ближе всего к игроку.
    for (int i = 0; i < (int)state.field.size(); i++) {
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            if (state.field[i][j] == 0) {
                // Манхэттенское расстояние — это число шагов по строкам
                // и столбцам, если временно не учитывать препятствия.
                int distance = std::abs(state.row - i) + std::abs(state.col - j);

                if (distance < best_distance) {
                    best_distance = distance;
                }
            }
        }
    }

    // Почему remaining - 1 + best_distance?
    // До первой новой клетки надо как минимум best_distance шагов.
    // После нее остается еще remaining - 1 новых клеток,
    // и каждая из них потребует хотя бы одного шага.
    //
    // Препятствия здесь не учитываются специально:
    // из-за этого оценка может быть меньше реального расстояния,
    // но не завышает его. Для A* это полезное свойство.
    return (remaining - 1) + best_distance;
}

// ------------------------------------------------------------
// Для A* нужен узел с приоритетом.
// f = g + h
// g — сколько ходов уже сделано;
// h — оценка оставшегося пути.
// ------------------------------------------------------------
struct AStarNode {
    State state;
    int depth;
    int priority;
    std::string path;

    AStarNode(const State& s, int d, int p, const std::string& way) {
        state = s;
        depth = d;
        priority = p;
        path = way;
    }
};

// priority_queue обычно достает самый большой элемент.
// Нам, наоборот, нужен узел с наименьшим f,
// поэтому сравнение здесь записано в обратную сторону.
struct AStarCompare {
    bool operator()(const AStarNode& a, const AStarNode& b) const {
        if (a.priority != b.priority) {
            return a.priority > b.priority;
        }

        return a.depth > b.depth;
    }
};

SearchResult ASTAR_solve(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col,
                         int heuristic_id) {
    SearchResult result;

    std::chrono::steady_clock::time_point begin =
        std::chrono::steady_clock::now();

    State initial = make_initial_state(field, start_row, start_col);

    std::priority_queue<AStarNode,
                        std::vector<AStarNode>,
                        AStarCompare> open;

    // best_g хранит самую короткую известную длину пути
    // до каждого состояния.
    std::unordered_map<std::string, int> best_g;

    int h = 0;
    if (heuristic_id == 1) {
        h = heuristic1(initial);
    } else {
        h = heuristic2(initial);
    }

    open.push(AStarNode(initial, 0, h, ""));
    best_g[state_key(initial)] = 0;

    while (!open.empty()) {
        AStarNode current = open.top();
        open.pop();

        std::string current_key = state_key(current.state);

        // В priority_queue может остаться старая, более длинная запись
        // того же состояния. Ее просто пропускаем.
        if (best_g[current_key] != current.depth) {
            continue;
        }

        result.expanded++;

        if (is_goal(current.state)) {
            result.found = true;
            result.path = current.path;
            result.solution_length = current.depth;
            break;
        }

        std::vector<Successor> next_states = get_successors(current.state);

        for (int i = 0; i < (int)next_states.size(); i++) {
            int new_g = current.depth + 1;
            std::string key = state_key(next_states[i].state);

            std::unordered_map<std::string, int>::iterator it = best_g.find(key);

            if (it == best_g.end() || new_g < it->second) {
                best_g[key] = new_g;

                int new_h;
                if (heuristic_id == 1) {
                    new_h = heuristic1(next_states[i].state);
                } else {
                    new_h = heuristic2(next_states[i].state);
                }

                int f = new_g + new_h;

                open.push(AStarNode(next_states[i].state,
                                    new_g,
                                    f,
                                    current.path + next_states[i].move));
            }
        }
    }

    std::chrono::steady_clock::time_point end =
        std::chrono::steady_clock::now();

    result.elapsed_ms =
        std::chrono::duration<double, std::milli>(end - begin).count();

    return result;
}
