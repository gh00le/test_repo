#ifndef AI_H
#define AI_H

#include "common.h"

// Поиск в ширину.
SearchResult BFS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col);

// Ограниченный поиск в глубину.
SearchResult DLS_solve(const std::vector<std::vector<int> >& field,
                       int start_row,
                       int start_col,
                       int limit);

// Эвристический поиск A*.
// heuristic_id = 1 -> эвристика H1.
// heuristic_id = 2 -> эвристика H2.
SearchResult ASTAR_solve(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col,
                         int heuristic_id);

// H1: число оставшихся незакрашенных клеток.
int heuristic1(const State& state);

// H2: число оставшихся клеток + расстояние до ближайшей из них.
int heuristic2(const State& state);

#endif
