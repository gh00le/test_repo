#include "interface.h"

void print_field(const std::vector<std::vector<int> >& field,
                 int player_row,
                 int player_col) {
    std::cout << "\nПоле:\n";
    std::cout << "P = игрок, # = препятствие, 0 = не окрашено, 1 = окрашено\n\n";

    for (int i = 0; i < (int)field.size(); i++) {
        for (int j = 0; j < (int)field[i].size(); j++) {
            if (i == player_row && j == player_col) {
                std::cout << " P ";
            } else if (field[i][j] == -1) {
                std::cout << " # ";
            } else {
                std::cout << ' ' << field[i][j] << ' ';
            }
        }
        std::cout << '\n';
    }

    std::cout << '\n';
}

void print_result(const std::string& algorithm,
                  const SearchResult& result,
                  int dls_limit) {
    std::cout << "---------------------------------------------\n";
    std::cout << "Алгоритм: " << algorithm << '\n';

    if (dls_limit >= 0) {
        std::cout << "Ограничение глубины: " << dls_limit << '\n';
    }

    std::cout << "Решение найдено: " << (result.found ? "да" : "нет") << '\n';
    std::cout << "Раскрыто вершин: " << result.expanded << '\n';
    std::cout << "Время: " << std::fixed << std::setprecision(4)
              << result.elapsed_ms << " мс\n";

    if (result.found) {
        std::cout << "Длина решения: " << result.solution_length << '\n';
        std::cout << "Путь: " << result.path << '\n';
        std::cout << "Обозначения: U=вверх, R=вправо, D=вниз, L=влево\n";
    }
}
