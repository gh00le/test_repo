#include "game8.h"

// ------------------------------------------------------------
// В этой работе приняты такие обозначения клеток:
//   0  - проходимая, но еще НЕ закрашенная клетка;
//   1  - проходимая и уже закрашенная клетка;
//  -1  - препятствие (стена), туда игрок идти не может.
//
// Игрок ходит только вверх, вправо, вниз и влево.
// Если он приходит на клетку 0, она становится 1.
// Если он снова приходит на клетку 1, она так и остается 1.
// То есть клетка никогда не "перекрашивается обратно".
// ------------------------------------------------------------

bool is_valid_start(const std::vector<std::vector<int> >& field,
                    int row,
                    int col) {
    if (field.empty()) {
        return false;
    }

    if (row < 0 || row >= (int)field.size()) {
        return false;
    }

    if (col < 0 || col >= (int)field[0].size()) {
        return false;
    }

    // На стене начинать нельзя.
    if (field[row][col] == -1) {
        return false;
    }

    return true;
}

State make_initial_state(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col) {
    State state;
    state.field = field;
    state.row = start_row;
    state.col = start_col;

    // По условию клетка под игроком уже окрашена.
    state.field[start_row][start_col] = 1;

    return state;
}

bool is_goal(const State& state) {
    // Перебираем все строки поля.
    for (int i = 0; i < (int)state.field.size(); i++) {
        // Перебираем все клетки в строке.
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            // Если нашли хотя бы один 0,
            // значит еще осталась незакрашенная клетка.
            if (state.field[i][j] == 0) {
                return false;
            }
        }
    }

    // Если ни одного 0 не осталось, цель достигнута.
    return true;
}

int count_unpainted(const State& state) {
    int count = 0;

    for (int i = 0; i < (int)state.field.size(); i++) {
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            if (state.field[i][j] == 0) {
                count++;
            }
        }
    }

    return count;
}

std::vector<Successor> get_successors(const State& state) {
    std::vector<Successor> result;

    // Изменения координат для четырех направлений:
    // U = вверх, R = вправо, D = вниз, L = влево.
    const int dr[4] = {-1, 0, 1, 0};
    const int dc[4] = {0, 1, 0, -1};
    const char names[4] = {'U', 'R', 'D', 'L'};

    int rows = (int)state.field.size();
    int cols = (int)state.field[0].size();

    for (int i = 0; i < 4; i++) {
        int new_row = state.row + dr[i];
        int new_col = state.col + dc[i];

        // Сначала проверяем, что не вышли за границы поля.
        if (new_row < 0 || new_row >= rows ||
            new_col < 0 || new_col >= cols) {
            continue;
        }

        // На клетку -1 наступать нельзя: это препятствие.
        if (state.field[new_row][new_col] == -1) {
            continue;
        }

        // Создаем копию текущего состояния.
        State next = state;

        // Перемещаем игрока.
        next.row = new_row;
        next.col = new_col;

        // Клетка становится окрашенной.
        // Если там уже была 1, ничего плохого не происходит:
        // значение просто остается равным 1.
        next.field[new_row][new_col] = 1;

        Successor s;
        s.state = next;
        s.move = names[i];
        result.push_back(s);
    }

    return result;
}

std::string state_key(const State& state) {
    // Нам нужна строка, которая однозначно описывает состояние.
    // Тогда ее можно положить в unordered_set / unordered_map
    // и быстро проверить: встречали мы такое состояние раньше или нет.
    std::ostringstream out;

    out << state.row << ',' << state.col << '|';

    for (int i = 0; i < (int)state.field.size(); i++) {
        for (int j = 0; j < (int)state.field[i].size(); j++) {
            if (state.field[i][j] == -1) {
                out << 'X';
            } else {
                out << state.field[i][j];
            }
        }
        out << '/';
    }

    return out.str();
}
