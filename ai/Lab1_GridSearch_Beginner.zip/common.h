#ifndef COMMON_H
#define COMMON_H

#include <iostream>
#include <vector>
#include <string>
#include <queue>
#include <unordered_set>
#include <unordered_map>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <cmath>
#include <limits>

// ------------------------------------------------------------
// Этот файл содержит самые общие структуры программы.
// Их используют сразу несколько .cpp файлов.
// ------------------------------------------------------------

// State (состояние) — это "фотография" задачи в один момент времени.
// Нам важно знать две вещи:
// 1) какие клетки уже закрашены;
// 2) где сейчас находится игрок.
struct State {
    std::vector<std::vector<int> > field; // Само поле.
    int row;                              // Строка игрока.
    int col;                              // Столбец игрока.

    State() {
        row = 0;
        col = 0;
    }
};

// SearchResult хранит итог работы одного алгоритма.
// Так удобнее: функция поиска возвращает сразу все нужные результаты.
struct SearchResult {
    bool found;              // true, если решение найдено.
    std::string path;        // Последовательность ходов: U, D, L, R.
    int solution_length;     // Сколько ходов в найденном решении.
    long long expanded;      // Сколько вершин (состояний) было раскрыто.
    double elapsed_ms;       // Время работы в миллисекундах.

    SearchResult() {
        found = false;
        path = "";
        solution_length = -1;
        expanded = 0;
        elapsed_ms = 0.0;
    }
};

// Successor — один возможный следующий шаг.
// Здесь хранится новое состояние и буква сделанного хода.
struct Successor {
    State state;
    char move;
};

#endif
