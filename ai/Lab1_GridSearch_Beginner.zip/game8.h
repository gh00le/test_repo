#ifndef GAME8_H
#define GAME8_H

#include "common.h"

// Создает начальное состояние.
// Клетка, где стоит игрок, сразу становится закрашенной (1).
State make_initial_state(const std::vector<std::vector<int> >& field,
                         int start_row,
                         int start_col);

// Проверяет, достигнута ли цель:
// на поле не должно остаться ни одной проходимой клетки со значением 0.
bool is_goal(const State& state);

// Создает все состояния, в которые игрок может перейти за один ход.
std::vector<Successor> get_successors(const State& state);

// Превращает состояние в строку.
// Такая строка используется как ключ, чтобы узнавать уже посещенные состояния.
std::string state_key(const State& state);

// Считает, сколько незакрашенных клеток (0) еще осталось.
int count_unpainted(const State& state);

// Проверяет, корректны ли координаты игрока и можно ли стоять на этой клетке.
bool is_valid_start(const std::vector<std::vector<int> >& field,
                    int row,
                    int col);

#endif
