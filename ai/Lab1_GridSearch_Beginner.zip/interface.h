#ifndef INTERFACE_H
#define INTERFACE_H

#include "common.h"

// Красиво печатает поле в консоль.
void print_field(const std::vector<std::vector<int> >& field,
                 int player_row,
                 int player_col);

// Печатает результат одного алгоритма.
void print_result(const std::string& algorithm,
                  const SearchResult& result,
                  int dls_limit = -1);

#endif
