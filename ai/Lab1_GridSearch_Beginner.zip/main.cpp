#include "common.h"
#include "game8.h"
#include "ai.h"
#include "interface.h"

// ------------------------------------------------------------
// TestCase — просто удобная упаковка одного теста.
// Вместо пяти отдельных наборов переменных мы храним все вместе.
// ------------------------------------------------------------
struct TestCase {
    std::string name;
    std::vector<std::vector<int> > field;
    int start_row;
    int start_col;
    int dls_limit;
};

// Запускает все четыре варианта поиска для одного поля.
void run_one_test(const TestCase& test) {
    std::cout << "\n=================================================\n";
    std::cout << test.name << '\n';
    std::cout << "Старт игрока: (" << test.start_row
              << ", " << test.start_col << ")\n";

    print_field(test.field, test.start_row, test.start_col);

    SearchResult bfs = BFS_solve(test.field,
                                 test.start_row,
                                 test.start_col);

    SearchResult dls = DLS_solve(test.field,
                                 test.start_row,
                                 test.start_col,
                                 test.dls_limit);

    SearchResult h1 = ASTAR_solve(test.field,
                                  test.start_row,
                                  test.start_col,
                                  1);

    SearchResult h2 = ASTAR_solve(test.field,
                                  test.start_row,
                                  test.start_col,
                                  2);

    print_result("BFS", bfs);
    print_result("DLS", dls, test.dls_limit);
    print_result("A* с эвристикой H1", h1);
    print_result("A* с эвристикой H2", h2);
}

// Режим со своими данными.
void run_custom_test() {
    int rows;
    int cols;

    std::cout << "Введите количество строк: ";
    std::cin >> rows;

    std::cout << "Введите количество столбцов: ";
    std::cin >> cols;

    if (rows <= 0 || cols <= 0) {
        std::cout << "Размеры поля должны быть положительными.\n";
        return;
    }

    std::vector<std::vector<int> > field(rows,
                                         std::vector<int>(cols, 0));

    std::cout << "\nВведите поле построчно.\n";
    std::cout << "Используйте 0 для проходимой клетки и -1 для препятствия.\n";
    std::cout << "Например: 0 0 -1 0\n\n";

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            std::cin >> field[i][j];

            // Для начального ввода нам достаточно 0 и -1.
            if (field[i][j] != 0 && field[i][j] != -1) {
                std::cout << "Ошибка: разрешены только 0 и -1.\n";
                return;
            }
        }
    }

    int start_row;
    int start_col;

    std::cout << "Введите строку игрока (нумерация с 0): ";
    std::cin >> start_row;

    std::cout << "Введите столбец игрока (нумерация с 0): ";
    std::cin >> start_col;

    if (!is_valid_start(field, start_row, start_col)) {
        std::cout << "Такое начальное положение использовать нельзя.\n";
        return;
    }

    int limit;
    std::cout << "Введите ограничение глубины для DLS: ";
    std::cin >> limit;

    TestCase custom;
    custom.name = "Пользовательский тест";
    custom.field = field;
    custom.start_row = start_row;
    custom.start_col = start_col;
    custom.dls_limit = limit;

    run_one_test(custom);
}

int main() {
    std::cout << "Лабораторная работа №1\n";
    std::cout << "Алгоритмы поиска в пространстве состояний\n";
    std::cout << "Задача: закрасить все проходимые клетки поля\n\n";

    // В каждом тесте 0 означает незакрашенную клетку,
    // а -1 означает стену.
    // Клетку под игроком программа сама превратит в 1.
    std::vector<TestCase> tests;

    TestCase t1;
    t1.name = "Тест 1: поле 2 x 3 без препятствий";
    t1.field = {
        {0, 0, 0},
        {0, 0, 0}
    };
    t1.start_row = 0;
    t1.start_col = 0;
    t1.dls_limit = 8;
    tests.push_back(t1);

    TestCase t2;
    t2.name = "Тест 2: поле 3 x 3, препятствие в центре";
    t2.field = {
        {0, 0, 0},
        {0, -1, 0},
        {0, 0, 0}
    };
    t2.start_row = 0;
    t2.start_col = 0;
    t2.dls_limit = 10;
    tests.push_back(t2);

    TestCase t3;
    t3.name = "Тест 3: поле 3 x 4 с двумя препятствиями";
    t3.field = {
        {0, 0, 0, 0},
        {0, -1, -1, 0},
        {0, 0, 0, 0}
    };
    t3.start_row = 1;
    t3.start_col = 0;
    t3.dls_limit = 14;
    tests.push_back(t3);

    TestCase t4;
    t4.name = "Тест 4: поле 4 x 4 с тремя препятствиями";
    t4.field = {
        {0, 0, 0, -1},
        {-1, 0, 0, 0},
        {0, 0, -1, 0},
        {0, 0, 0, 0}
    };
    t4.start_row = 0;
    t4.start_col = 0;
    t4.dls_limit = 18;
    tests.push_back(t4);

    TestCase t5;
    t5.name = "Тест 5: поле 4 x 4 с четырьмя препятствиями";
    t5.field = {
        {0, 0, -1, 0},
        {0, 0, -1, 0},
        {0, 0, 0, 0},
        {-1, 0, -1, 0}
    };
    t5.start_row = 0;
    t5.start_col = 0;
    t5.dls_limit = 18;
    tests.push_back(t5);

    while (true) {
        std::cout << "\nВыберите режим:\n";
        std::cout << "1 - запустить 5 готовых тестов\n";
        std::cout << "2 - ввести свое поле\n";
        std::cout << "0 - выход\n";
        std::cout << "> ";

        int choice;
        std::cin >> choice;

        if (choice == 0) {
            break;
        }

        if (choice == 1) {
            for (int i = 0; i < (int)tests.size(); i++) {
                run_one_test(tests[i]);
            }
        } else if (choice == 2) {
            run_custom_test();
        } else {
            std::cout << "Неизвестный пункт меню.\n";
        }
    }

    return 0;
}
